/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ExamenSupermercado;

/**
 *
 * @author Fran
 */
public class Producto {
    private int codigo;
    private String nombre;
    private String marca;
    private int cantidadDeUnidadesAExhibir;
    private double precioUnitario;

    public Producto(int codigo, String nombre, String marca, int cantidadDeUnidadesAExhibir, double precioUnitario) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.marca = marca;
        this.cantidadDeUnidadesAExhibir = cantidadDeUnidadesAExhibir;
        this.precioUnitario = precioUnitario;
    }

    public String getMarca() {
        return marca;
    }

    public int getCantidadDeUnidadesAExhibir() {
        return cantidadDeUnidadesAExhibir;
    }

    
    
    @Override
    public String toString() {
        return "Producto{"  + codigo + ", "+ nombre + ", " + marca + ", " + cantidadDeUnidadesAExhibir + ", " + precioUnitario + '}';
    }

    private void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    private void setNombre(String nombre) {
        this.nombre = nombre;
    }

    private void setMarca(String marca) {
        this.marca = marca;
    }

    private void setCantidadDeUnidadesAExhibir(int cantidadDeUnidadesAExhibir) {
        this.cantidadDeUnidadesAExhibir = cantidadDeUnidadesAExhibir;
    }

    private void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }
    
    
}
