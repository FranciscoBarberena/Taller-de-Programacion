/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ExamenSupermercado;

/**
 *
 * @author Fran
 */
public class Supermercado {
    private String nombre;
    private String direccion;
    private Producto[][] matriz;
    private int G;
    private int E;
    private int DL;

    public Supermercado(String nombre, String direccion, int G, int E) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.G = G;
        this.E = E;
        this.DL = 0;
        matriz = new Producto[G][E];
    }
    
    public boolean agregarProducto(Producto P){
        if (!estaLleno()){
            matriz[DL/E][DL%E] = P;
            DL++;
            return true;
        } else return false;
    }
    
    private boolean estaLleno(){
        return DL == G*E;
    }
    
    public String productosCumplenGondolaX (String unaMarca,int numGondola){
        String aux ="";
        int i =0;
        while(i<E){
            if (matriz[numGondola-1][i].getMarca().equals(unaMarca))
                aux+= "\n"+matriz[numGondola-1][i].toString();
            i++;
        }
        if (!aux.equals(""))
            return aux;
        else return "No hay productos de la marca "+unaMarca+" en la gondola "+numGondola;
    }
    
    private int contarGondolaG(int unaG){
        int aux =0;
        for (int i =0;i<E;i++)
            aux+=matriz[unaG][i].getCantidadDeUnidadesAExhibir();
        return aux;
    }
    
    public int encontrarGondolaMax(){
        int maxCant = -1;
        int gMax=-9; //asumo que está llena la matriz así que no pasa nada si devuelve -9
        for (int j =0; j<G;j++)
            if (contarGondolaG(j)>maxCant){
                maxCant = contarGondolaG(j);
                gMax = j;
            }
        return gMax+1;
    }
    
    /* d. Obtener un String que represente el supermercado siguiendo el ejemplo:
    "Supermercado: Nombre; Dirección
    Góndola 1:
    Estante 1: Producto{Código - nombre - marca - cantidad de unidades exhibidas - precio por unidad}
    Estante 2: Producto{Código - nombre - marca - cantidad de unidades exhibidas - precio por unidad}
    ...
    Góndola G:
    ..."*/

    private String getNombre() {
        return nombre;
    }

    private String getDireccion() {
        return direccion;
    }
    
    
    
    public String toString(){
        String aux = "Supermercado: "+getNombre()+"; "+getDireccion();
        for (int i =0;i<G;i++){
            aux+="\nGóndola "+(i+1);
            for (int j =0;j<E;j++)
                aux+="\n    Estante "+(j+1)+": "+matriz[i][j].toString();
        }
        return aux;
    }
    
    
}
