package ExamenSupermercado;

/*
Se desea modelar un supermercado. Un supermercado tiene nombre, dirección y mantiene una estructura que para cada góndola (1..G) y cada estante de la góndola (1..E) 
almacena el producto a exhibir. De cada producto a exhibir se guarda código, nombre, marca, cantidad de unidades exhibidas y precio por unidad.

Genere las clases necesarias. Provea constructores para iniciar: los productos a partir de la información necesaria; el supermercado a partir de un nombre, una dirección, 
una cantidad de góndolas G y una cantidad de estantes por góndola E. Inicialmente la estructura no tiene productos a exhibir.

    Implemente los métodos necesarios, en las clases que corresponda, para:

    a. Registrar un producto a exhibir, teniendo en cuenta que primero se completa la primera góndola en estantes sucesivos, luego la segunda y así siguiendo.

Para los siguientes métodos, asuma que todas las góndolas tienen en todos sus estantes productos exhibidos.

    b. Listar los productos exhibidos con marca M de la góndola X. Esto es: devolver un String con las representaciones de los productos que cumplen, con el siguiente formato:
    "Producto{Código - nombre - marca - cantidad de unidades exhibidas - precio por unidad}"

    c. Obtener el número de góndola con mayor cantidad total de unidades exhibidas. 
    La cantidad total de unidades exhibidas en una góndola es la suma de las unidades de los productos exhibidos en sus estantes.

    d. Obtener un String que represente el supermercado siguiendo el ejemplo:
    "Supermercado: Nombre; Dirección
    Góndola 1:
    Estante 1: Producto{Código - nombre - marca - cantidad de unidades exhibidas - precio por unidad}
    Estante 2: Producto{Código - nombre - marca - cantidad de unidades exhibidas - precio por unidad}
    ...
    Góndola G:
    ..."

    Realice un programa que instancie un supermercado. Registre todos los productos en las góndolas y estantes. Compruebe el correcto funcionamiento de los métodos implementados.
 */
import PaqueteLectura.GeneradorAleatorio;
import PaqueteLectura.Lector;
/**
 *
 * @author Fran
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GeneradorAleatorio.iniciar();
        int cantidadGondolas = 5;
        int cantidadEstantes = 3;
        Supermercado superM = new Supermercado ("DISCO","Calle 473 bis y Belgrano",cantidadGondolas,cantidadEstantes);
        Producto productoAux = new Producto (2,"MUCHACANTIDAD","MUCHACANTIDAD",99999999,1);
        for (int i=0;i<3;i++){ //lleno gondola 1 con valores altos para probar maximo
            superM.agregarProducto(productoAux);
        }
        for (int i =1;i<cantidadGondolas;i++){ //lleno resto de gondolas
            for (int j = 0; j<cantidadEstantes;j++){
                productoAux = new Producto(GeneradorAleatorio.generarInt(5000)+1000,"productoGenerico","marcaGenerica",GeneradorAleatorio.generarInt(200)+1,GeneradorAleatorio.generarDouble(10000)+50);
                superM.agregarProducto(productoAux);
            }
        }
        
        System.out.println(superM.toString());
        System.out.print("Ingresa la marca a buscar: ");
        String marcaAExhibir = Lector.leerString();
        System.out.print("Ingresa la gondola a buscar: ");
        int gonAExhibir = Lector.leerInt();
        System.out.println("Los productos en la gondola "+gonAExhibir+ " de la marca "+marcaAExhibir+" fue: "+superM.productosCumplenGondolaX(marcaAExhibir, gonAExhibir));
        System.out.println("La gondola con mayor cantidad de unidades exhibidas fue la gondola "+superM.encontrarGondolaMax());
    }
}
