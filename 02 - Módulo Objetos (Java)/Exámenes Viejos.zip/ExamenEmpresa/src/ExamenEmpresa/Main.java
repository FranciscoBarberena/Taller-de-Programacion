package ExamenEmpresa;

/*
2. Módulo Objetos: Empresa y Empleados (Turno F, 10/10/2023)
Representar una Empresa. La empresa tiene nombre, una dirección, un director ejecutivo y los Encargados de sus sucursales numeradas de la 1..N.
Del Director se conoce el nombre, DNI, año de ingreso a la empresa, sueldo básico y monto destinado a viáticos.
Del Encargado de cada sucursal se conoce el nombre, DNI, año de ingreso a la empresa, sueldo básico y cantidad de empleados a cargo.
a) Genere las clases necesarias.
Provea constructores para iniciarlas a partir de la información necesaria. En el caso de la Empresa debe considerar que se crea con nombre, dirección, un Director y N sucursales inicialmente sin Encargados.
b) Implemente los métodos necesarios, en las clases que corresponda, para:
Asignar un Encargado a la sucursal X. Asuma que X está en rango de 1..N.
Retornar el sueldo a cobrar por los empleados (Encargados y Director). En ambos casos la empresa incorpora al sueldo básico una comisión del 10% si supera los 20 años de antigüedad.
Además, El Encargado tiene un adicional de 1000 pesos por cada empleado a cargo.
El Director recibe el monto destinado a viáticos.
Retornar una representación String de Director y Encargado, con formato: "Nombre, DNI, sueldo a cobrar".
Retornar un String que represente la empresa que contenga: nombre, dirección, representación String del Director y la representación de los Encargados junto a su número de sucursal. Indique si existe alguna sucursal sin Encargado.
c) Realice un programa que instancie una Empresa.
Cargue Encargados en distintas sucursales. Luego, imprima la representación de la Empresa.
 */
import PaqueteLectura.Lector;
import PaqueteLectura.GeneradorAleatorio;
/**
 *
 * @author Fran
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int N = Lector.leerInt();
        Director directorAux = new Director(20000,"Bill Gates",20555444,2022,1000000);
        Empresa emp = new Empresa("Microsoft","Calle 450",directorAux,N);
        Encargado encargadoAux;
        for (int i=0;i<emp.getN();i=GeneradorAleatorio.generarInt(emp.getN()+1)){
            encargadoAux = new Encargado(GeneradorAleatorio.generarInt(20)+1,GeneradorAleatorio.generarString(10),GeneradorAleatorio.generarInt(5000)+1000,GeneradorAleatorio.generarInt(2025-1990)+1990,GeneradorAleatorio.generarDouble(1000000));
            emp.asignarEncargado(encargadoAux,i);
            if (emp.asignarEncargado(encargadoAux,i))
                System.out.println("Se agregó con exito el encargado.");
            else System.out.println("La sucursal ya estaba ocupada por otro encargado.");
        }
        System.out.println(emp.toString());
    }
    
}
