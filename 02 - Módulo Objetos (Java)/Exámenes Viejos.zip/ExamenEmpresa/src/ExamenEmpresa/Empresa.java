/*
2. Módulo Objetos: Empresa y Empleados (Turno F, 10/10/2023)
Representar una Empresa. La empresa tiene nombre, una dirección, un director ejecutivo y los Encargados de sus sucursales numeradas de la 1..N.
Del Director se conoce el nombre, DNI, año de ingreso a la empresa, sueldo básico y monto destinado a viáticos.
Del Encargado de cada sucursal se conoce el nombre, DNI, año de ingreso a la empresa, sueldo básico y cantidad de empleados a cargo.
a) Genere las clases necesarias.
Provea constructores para iniciarlas a partir de la información necesaria. En el caso de la Empresa debe considerar que se crea con nombre, dirección, un Director y N sucursales 
inicialmente sin Encargados.
b) Implemente los métodos necesarios, en las clases que corresponda, para:
Asignar un Encargado a la sucursal X. Asuma que X está en rango de 1..N.

Retornar el sueldo a cobrar por los empleados (Encargados y Director). En ambos casos la empresa incorpora al sueldo básico una comisión del 10% si supera los 20 años de antigüedad.
Además, El Encargado tiene un adicional de 1000 pesos por cada empleado a cargo.
El Director recibe el monto destinado a viáticos.

Retornar una representación String de Director y Encargado, con formato: "Nombre, DNI, sueldo a cobrar".
Retornar un String que represente la empresa que contenga: nombre, dirección, representación String del Director y la representación de los Encargados junto a su número de sucursal. Indique si existe alguna sucursal sin Encargado.
c) Realice un programa que instancie una Empresa.
Cargue Encargados en distintas sucursales. Luego, imprima la representación de la Empresa.
 */
package ExamenEmpresa;

/**
 *
 * @author Fran
 */
public class Empresa {
    private String nombre;
    private String direccion;
    private Director directorEjecutivo;
    private Encargado[] vector;
    private int N;

    
    
    public Empresa(String nombre, String direccion, Director directorEjecutivo, int N) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.directorEjecutivo = directorEjecutivo;
        this.N = N;
        vector = new Encargado[N];
        for (int i=0; i<N;i++)
            vector[i]=null; //porque no se agregan secuencialmente
    }
    
    public boolean asignarEncargado(Encargado e,int numSucursal){
        if (!(vector[numSucursal] == null))
            return false;
        else {
            vector[numSucursal] = e;
            return true;
        }
    }
    
    public double calcularTotalSueldos (){
        double aux = directorEjecutivo.calcularSueldo();
        for (int i=0; i<N;i++){
            if (vector[i] != null)
                aux+=vector[i].calcularSueldo();
        }
        return aux;
    }
    
    public String toString(){
        String aux="Nombre de la empresa: "+getNombre()+"\nDirección de la empresa: "+getDireccion()+"\nDirector de la empresa: "+directorEjecutivo.toString()+"\nEncargados de la empresa: ";
        for (int i =0; i<N;i++)
            if (vector[i]!= null)
                aux+="\nEncargado de la sucursal "+(i+1)+": "+vector[i].toString();
            else aux+="\nLa sucursal "+(i+1)+" no tiene encargado";
        return aux;
    }

    private String getNombre() {
        return nombre;
    }

    private String getDireccion() {
        return direccion;
    }

    public int getN() {
        return N;
    }
    
    
    
    
}
