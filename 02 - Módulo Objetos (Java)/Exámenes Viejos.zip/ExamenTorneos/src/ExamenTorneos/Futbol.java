/*
 Una empresa organiza dos tipos de torneos (de fútbol y de tenis). De cualquier torneo se conoce su nombre, fecha de inicio, 
costo de inscripción por jugador y monto del premio a otorgar al ganador. 
De los torneos de fútbol se conoce la información de los equipos inscriptos (como máximo N); de cada equipo se registra el nombre del equipo, lugar de origen y nombre del técnico. 
De los torneos de tenis se conoce la cantidad de jugadores inscriptos y el tipo de superficie de la cancha (String).

1. Genere las clases necesarias. Implemente constructores para iniciar los diferentes torneos a partir de la información necesaria; los torneos de fútbol se deben iniciar sin equipos
y con capacidad máxima para guardar N equipos.

2. Implemente los métodos necesarios en las clases que corresponda, para:

a) Agregar un equipo a un torneo de fútbol.

b) Obtener la recaudación del torneo considerando que:

    Si el torneo es de fútbol, se asume que cada equipo tiene 11 jugadores, por lo tanto se recauda:
    costo_inscripción_por_jugador * ( 11 * cantidad_equipos_inscriptos )

    Si el torneo es de tenis, se recauda:
    costo_inscripcion_por_jugador * cantidad_jugadores_inscriptos

c) Retornar si el torneo es viable económicamente. Un torneo es viable si la recaudación del torneo supera el doble del monto del premio a otorgar al ganador.

d) Devolver un String que represente al torneo conforme el siguiente ejemplo:

    "Nombre del Torneo:...Fecha:...Monto a otorgar al ganador:...Recaudación del torneo:...Es Viable:..."

3. Escriba un programa que instancie un torneo de fútbol y uno de tenis, cargue los datos necesarios y presente por consola la representación en String de cada torneo.
 */
package ExamenTorneos;

/**
 *
 * @author Fran
 */
public class Futbol extends Torneo{
    private Equipo[] equipos;
    private int N;
    private int DL;

    public Futbol(String nombre, String fechaDeInicio, double costoPorJugador, double montoPremio,int N) {
        super(nombre, fechaDeInicio, costoPorJugador, montoPremio);
        this.N = N;
        equipos = new Equipo[N];
    }
    
    public boolean agregarEquipo(Equipo e){
        if (!estaLleno()){
            equipos[DL]=e;
            DL++;
            return true;
        } else return false;  
    }
    
    private boolean estaLleno(){
        return DL == N;
    }
    
    public double calcularRecaudacion(){
        double aux = this.getCostoPorJugador();
        aux=aux*11*N;
        return aux;
    }
    
}
