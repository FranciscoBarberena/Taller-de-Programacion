/*
Una universidad necesita un sistema para administrar los exámenes finales rendidos por sus alumnos. 
La universidad maneja hasta un máximo de N alumnos, de los cuales desea conocer nombre, apellido y nº de legajo (string). 
Un mismo alumno puede rendir hasta M exámenes diferentes. De cada examen se conoce mes y año de cuando se rindió, la calificación obtenida y la modalidad del examen 
(escrito, oral, trabajo integrador, etc.).

1) Modele el problema generando las clases que considere necesarias, cada una con los constructores, estado, getters y setters que considere necesarios.

2) Implemente en las clases realizadas los métodos necesarios para incorporar la siguiente funcionalidad:
    a) Agregar un nuevo alumno a la universidad (Asuma que hay lugar).
    b) Agregar un nuevo examen rendido por un alumno cuyo nº de legajo se recibe por parámetro (El nº de legajo recibido podría no pertenecer a ningún alumno. Asuma que hay lugar).
    c) Obtener la cantidad de exámenes rendidos en un determinado mes y año bajo cierta modalidad. El mes, año y la modalidad se reciben por parámetro.
    d) Devolver el alumno que tiene el mejor promedio.

3) Implemente una función main que cree una universidad para administrar 1000 alumnos. Simule el ingreso de dos alumnos (con máximo de exámenes de 10), 
agregue dos exámenes rendidos a cada alumno. Imprima la cantidad de exámenes rendidos bajo una cierta modalidad, en un determinado mes y año; 
todos los datos leídos por teclado. Imprima nombre y apellido del alumno con mejor promedio.
 */
package ExamenAlumnos;

/**
 *
 * @author Fran
 */
public class Alumno {
    private String nombre;
    private String apellido;
    private String legajo;
    private Examen[] examenes;
    private int M;
    private int DL;

    public Alumno(String nombre, String apellido, String legajo, int M) {
        this.nombre = nombre;
        this.DL = 0;
        this.apellido = apellido;
        this.legajo = legajo;
        this.M = M;
        examenes = new Examen[M];
    }

    public String getLegajo() {
        return legajo;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }
    
    
    
    public void agregarExamen (Examen e){ //no retorna boolean porque asumo que hay lugar
        examenes[DL]=e;
        this.DL++;
    }
    
     public int cantExamenesCumplen (int unMes, int unAño, String unaModalidad){
        int aux = 0;
        for (int i =0;i<DL;i++)
            if (examenes[i].cumple(unMes,unAño,unaModalidad))
                aux++;
        return aux;
     }
     
     public double calcularPromedio(){
         double suma =0;
         for (int i =0;i<DL;i++)
            suma+=examenes[i].getNota();
         if (DL!=0)
             return suma/DL;
         else return -1; //caso en el que no rindio ningun examen, para evitar división por 0
         
     }
       

    
    
    
}
