/*
Una universidad necesita un sistema para administrar los exámenes finales rendidos por sus alumnos. 
La universidad maneja hasta un máximo de N alumnos, de los cuales desea conocer nombre, apellido y nº de legajo (string). 
Un mismo alumno puede rendir hasta M exámenes diferentes. De cada examen se conoce mes y año de cuando se rindió, la calificación obtenida y la modalidad del examen 
(escrito, oral, trabajo integrador, etc.).

1) Modele el problema generando las clases que considere necesarias, cada una con los constructores, estado, getters y setters que considere necesarios.

2) Implemente en las clases realizadas los métodos necesarios para incorporar la siguiente funcionalidad:
    a) Agregar un nuevo alumno a la universidad (Asuma que hay lugar).
    b) Agregar un nuevo examen rendido por un alumno cuyo nº de legajo se recibe por parámetro (El nº de legajo recibido podría no pertenecer a ningún alumno. Asuma que hay lugar).
    c) Obtener la cantidad de exámenes rendidos en un determinado mes y año bajo cierta modalidad. El mes, año y la modalidad se reciben por parámetro.
    d) Devolver el alumno que tiene el mejor promedio.

3) Implemente una función main que cree una universidad para administrar 1000 alumnos. Simule el ingreso de dos alumnos (con máximo de exámenes de 10), 
agregue dos exámenes rendidos a cada alumno. Imprima la cantidad de exámenes rendidos bajo una cierta modalidad, en un determinado mes y año; 
todos los datos leídos por teclado. Imprima nombre y apellido del alumno con mejor promedio.
 */
package ExamenAlumnos;

/**
 *
 * @author Fran
 */
public class Universidad {
    private int N;
    private Alumno[] alumnos;
    private int DL;

    public Universidad(int N) {
        this.N = N;
        this.DL = 0;
        alumnos = new Alumno[N];
    }
    
    public void agregarAUniversidad(Alumno a){ //no retorna boolean porque dice "asuma que hay lugar".
        alumnos[DL] = a;
        this.DL++;
    }
    
    /* b) Agregar un nuevo examen rendido por un alumno cuyo nº de legajo se recibe por parámetro 
    (El nº de legajo recibido podría no pertenecer a ningún alumno. Asuma que hay lugar).*/
    
    public boolean agregarExamenALegajo (Examen e, String unLegajo){
        int i = 0;
        while((i<N) && (!alumnos[i].getLegajo().equals(unLegajo)))
            i++;
        if ((i<N) && (alumnos[i].getLegajo().equals(unLegajo))){
            alumnos[i].agregarExamen(e);
            return true; //avisa que el legajo pertenecía a un alumno
        }
        else return false; //avisa que el legajo NO pertenecía a un alumno
    }
    /* c) Obtener la cantidad de exámenes rendidos en un determinado mes y año bajo cierta modalidad. 
    El mes, año y la modalidad se reciben por parámetro.*/
    
    public int cantExamenesCumplen (int unMes, int unAño, String unaModalidad){
        int aux = 0;
        for (int i =0; i<DL;i++)
            aux+=alumnos[i].cantExamenesCumplen(unMes,unAño,unaModalidad);
        return aux;
    }
    
    public Alumno alumnoConMejorPromedio(){
        double maxPromedio = -2;
        int posAux = -1;
        for (int i =0;i<DL;i++){
            if(alumnos[i].calcularPromedio()>maxPromedio){
                maxPromedio = alumnos[i].calcularPromedio();
                posAux = i;
            }
        }
        if (DL!= 0)
            return alumnos[posAux];
        else return null; //caso universidad vacia, para no retornar alumnos[-1]
    }
    
}
