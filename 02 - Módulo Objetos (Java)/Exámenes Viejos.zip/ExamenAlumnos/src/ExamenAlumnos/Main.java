package ExamenAlumnos;

/*
Una universidad necesita un sistema para administrar los exámenes finales rendidos por sus alumnos. 
La universidad maneja hasta un máximo de N alumnos, de los cuales desea conocer nombre, apellido y nº de legajo (string). 
Un mismo alumno puede rendir hasta M exámenes diferentes. De cada examen se conoce mes y año de cuando se rindió, la calificación obtenida y la modalidad del examen 
(escrito, oral, trabajo integrador, etc.).

1) Modele el problema generando las clases que considere necesarias, cada una con los constructores, estado, getters y setters que considere necesarios.

2) Implemente en las clases realizadas los métodos necesarios para incorporar la siguiente funcionalidad:
    a) Agregar un nuevo alumno a la universidad (Asuma que hay lugar).
    b) Agregar un nuevo examen rendido por un alumno cuyo nº de legajo se recibe por parámetro (El nº de legajo recibido podría no pertenecer a ningún alumno. Asuma que hay lugar).
    c) Obtener la cantidad de exámenes rendidos en un determinado mes y año bajo cierta modalidad. El mes, año y la modalidad se reciben por parámetro.
    d) Devolver el alumno que tiene el mejor promedio.

3) Implemente una función main que cree una universidad para administrar 1000 alumnos. Simule el ingreso de dos alumnos (con máximo de exámenes de 10), 
agregue dos exámenes rendidos a cada alumno. Imprima la cantidad de exámenes rendidos bajo una cierta modalidad, en un determinado mes y año; 
todos los datos leídos por teclado. Imprima nombre y apellido del alumno con mejor promedio.
 */
import PaqueteLectura.Lector;
/**
 *
 * @author Fran
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Universidad unlp = new Universidad(1000);
        int i;
        String auxNombre;
        String auxApellido;
        String auxLegajo;
        Alumno auxAlumno;
        int mesAux;
        int añoAux;
        double notaAux;
        String modalidadAux;
        Examen auxExamen;
        for (i =0; i<2;i++){
            System.out.print("Ingresar nombre: ");
            auxNombre = Lector.leerString();
            System.out.print("Ingresar apellido: ");
            auxApellido = Lector.leerString();
            System.out.print("Ingresar legajo: ");
            auxLegajo = Lector.leerString();
            auxAlumno = new Alumno(auxNombre,auxApellido,auxLegajo,10);
            unlp.agregarAUniversidad(auxAlumno);
            for (int j=0;j<2;j++){
                System.out.print("Ingresar mes del examen: ");
                mesAux = Lector.leerInt();
                System.out.print("Ingresar año del examen: ");
                añoAux = Lector.leerInt();
                System.out.print("Ingresar nota del examen: ");
                notaAux = Lector.leerDouble();
                System.out.print("Ingresar modalidad del examen: ");
                modalidadAux = Lector.leerString();
                auxExamen = new Examen(mesAux,añoAux,notaAux,modalidadAux);
                unlp.agregarExamenALegajo(auxExamen, auxLegajo);
            }
        }
        System.out.print("Ingresar modalidad a buscar: ");
        modalidadAux = Lector.leerString();
        System.out.print("Ingresar mes a buscar: ");
        mesAux = Lector.leerInt();
        System.out.print("Ingresar año a buscar: ");
        añoAux = Lector.leerInt();
        System.out.println("La cantidad de examenes rendidos en el año "+añoAux+", en el mes "+mesAux+" de modalidad "+modalidadAux+" fueron: "+unlp.cantExamenesCumplen(mesAux,añoAux,modalidadAux));
        System.out.println("El alumno con mejor promedio fue: "+unlp.alumnoConMejorPromedio().getNombre()+" "+unlp.alumnoConMejorPromedio().getApellido());  
    }  
 }
    

