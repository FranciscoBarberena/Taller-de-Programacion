/*
Una escuela de canto quiere organizar un concurso entre sus estudiantes y necesita un sistema que le permita administrar las canciones a interpretar, organizadas por categoría; 
además de conocer a los estudiantes que participan en el concurso. De las canciones se desea conocer su nombre, su compositor, su identificador (un número único para cada canción), 
el estudiante que hizo la mejor interpretación de la canción (el "ganador" de la canción) y el puntaje otorgado por los profesores. 
De los estudiantes se desea conocer su nombre, apellido y dni.

El concurso de canto debería crearse conociendo la cantidad de categorías y la cantidad máxima de canciones por categoría (la misma cantidad para todas las categorías). 
Las canciones deberían crearse con su identificador único, nombre, compositor y con el puntaje en cero. Los estudiantes deberían crearse con todos sus atributos.

Implemente las clases, atributos y métodos necesarios para poder realizar:

    Agregar una nueva canción al concurso en una determinada categoría (suponga que en dicha categoría hay lugar para la canción).

    Interpretar una canción. Se recibe el identificador de la canción (que seguro existe), el estudiante que hace la interpretación y el puntaje otorgado por los profesores. 
    Si el puntaje otorgado es más grande que el puntaje actual de la canción, se actualiza el puntaje y el estudiante "ganador" para la canción.

    Conocer el estudiante "ganador" de una canción, dado el identificador de la canción (que seguro existe),
   devuelve el estudiante que haya obtenido el puntaje más alto, o null si ningún estudiante interpretó la canción.

    Conocer la canción con el puntaje más grande en una determinada categoría.

Implemente un programa principal que realice lo siguiente:

    Cree un concurso de tres categorías y cinco canciones como máximo para cada categoría.

    Agregue cinco nuevas canciones.

    Vaya leyendo de teclado nombre, apellido y dni del estudiante, junto con el identificador de la canción y puntaje otorgado, hasta ingresar un identificador igual a cero. 
   "Simule" las interpretaciones de las canciones por los estudiantes invocando al método correspondiente.

    Lea un identificador de canción por teclado (que seguro existe) e informe el nombre, apellido y dni del estudiante "ganador". 
    OJO que la canción puede no haber sido interpretada por ningún estudiante, en cuyo caso se debería informar "Nadie".

    El nombre y compositor de la canción mejor interpretada para cada una de las cinco categorías.
 */
package ExamenCanto;

/**
 *
 * @author Fran
 */
public class Estudiante {
    private String nombre;
    private String apellido;
    private int DNI;

    public Estudiante(String nombre, String apellido, int DNI) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.DNI = DNI;
    }

    @Override
    public String toString() {
        return   nombre + " " + apellido;
    }
    
    
}
