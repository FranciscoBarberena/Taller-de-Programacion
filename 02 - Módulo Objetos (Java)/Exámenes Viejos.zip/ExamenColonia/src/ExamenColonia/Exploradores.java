/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ExamenColonia;

/**
 *
 * @author Fran
 */
public class Exploradores extends Grupo{
    private double costoAlquiler;

    public Exploradores(double costoAlquiler, Empleado instructor, double costoInscripcion, int N) {
        super(instructor, costoInscripcion, N);
        this.costoAlquiler = costoAlquiler;
    }
    
    public double calcularGananciaNeta(){
        double aux = super.calcularGananciaNeta();
        aux-= getCostoAlquiler();
        return aux;
    }

    private double getCostoAlquiler() {
        return costoAlquiler;
    }
    
    
    
    
}
