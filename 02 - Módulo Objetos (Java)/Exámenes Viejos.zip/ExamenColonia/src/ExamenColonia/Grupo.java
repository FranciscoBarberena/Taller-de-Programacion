/*
Representar dos tipos de grupos formados en una colonia de vacaciones: Nadadores y Exploradores. De cualquier grupo se conoce: nombre y sueldo del instructor,
el costo de inscripción y los chicos inscriptos (como máximo N). Además: los grupos Nadadores guardan el nombre y sueldo del bañero a cargo, 
mientras que los grupos Exploradores guardan el costo de alquiler de carpas a utilizar. De los chicos se registra: nombre, teléfono del responsable y si sabe nadar.

1- Genere las clases. Provea constructores para iniciar los objetos a partir de la información necesaria. 
En particular, los grupos deben iniciarse con capacidad para guardar un máximo de N inscriptos (y sin inscriptos inicialmente).

2- Implemente los métodos necesarios, en las clases que corresponda, para:

a) Dado un chico, agregarlo al grupo y retornar si tuvo éxito la operación. Tenga en cuenta que los grupos Nadadores deben agregar al chico sólo si sabe nadar. Asuma que hay espacio.
b) Obtener la ganancia neta del grupo, teniendo en cuenta que: es el costo de inscripción de los chicos anotados y a eso se resta el sueldo del instructor. 
Además de eso: los grupos Nadadores descuentan el sueldo del bañero, mientras que los grupos Exploradores descuentan el costo de alquiler de carpas.

c) Obtener un String que represente los grupos, siguiendo el ejemplo:

    "Nombre del Instructor, Cantidad de chicos inscriptos: X
    Datos del Chico 1, Datos del Chico 2, ...
    Ganancia Neta del grupo"

d) Determinar si el grupo es rentable. Es rentable si la ganancia neta supera los $5.000.000.

3- Realice un programa que instancie un grupo de cada tipo. Agregue algunos chicos a cada grupo. Imprima la representación String de cada grupo y para cada uno si es rentable o no.
 */
package ExamenColonia;

/**
 *
 * @author Fran
 */
public abstract class Grupo {
    private Empleado instructor;
    private double costoInscripcion;
    private double minimoRentable;
    private int cantChicosInscriptos; //DL
    private int N; //capacidad maxima
    private Chico[] vector;

    public Grupo(Empleado instructor, double costoInscripcion, int N) {
        this.instructor = instructor;
        this.costoInscripcion = costoInscripcion;
        this.cantChicosInscriptos = 0;
        this.N = N;
        this.minimoRentable = 5000000;
        vector = new Chico[N];
    }
    
    public boolean agregarAVector(Chico C){
        vector[cantChicosInscriptos] = C;
        this.cantChicosInscriptos++;
        return true;
    }

    private double getCostoInscripcion() {
        return costoInscripcion;
    }
    
    /*c) Obtener un String que represente los grupos, siguiendo el ejemplo:

    "Nombre del Instructor, Cantidad de chicos inscriptos: X
    Datos del Chico 1, Datos del Chico 2, ...
    Ganancia Neta del grupo"*/
    
    public String toString(){
        String aux = "Nombre del instructor: "+instructor.getNombre();
        aux+="\nCantidad de chicos inscriptos: "+cantChicosInscriptos;
        aux+="\nDatos de los chicos: ";
        for (int i =0;i<cantChicosInscriptos;i++){
            aux+="\nChico "+(i+1)+": "+vector[i].toString();
        }
        aux+="\nGanancia neta del grupo: $"+this.calcularGananciaNeta();
        return aux;
    }

    private double getMinimoRentable() {
        return minimoRentable;
    }
    
    
    
    public boolean esRentable(){
        if (this.calcularGananciaNeta()>getMinimoRentable())
            return true;
        else return false;
    }
    
    public double calcularCostoDeInscripcion(){
        double aux = getCostoInscripcion()*cantChicosInscriptos;
        return aux;
    }
    
    public double calcularGananciaNeta(){
        return this.calcularCostoDeInscripcion()-instructor.getSueldo();
    }
    
    
}
