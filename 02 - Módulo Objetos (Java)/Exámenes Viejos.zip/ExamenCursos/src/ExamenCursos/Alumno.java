/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ExamenCursos;

/**
 *
 * @author Fran
 */
public class Alumno {
    private String nombre;
    private int cantidadDeTareas;
    private double sumaTareas;
    
    public Alumno(String nombre) {
        this.cantidadDeTareas =0;
        this.sumaTareas = 0;
        this.nombre = nombre;
    }

    public void actualizarAlumno(double nota){
        this.setCantidadDeTareas(this.getCantidadDeTareas()+1);
        this.setSumaTareas(this.getSumaTareas()+nota);
    }
    
    public String toString(){
        String aux= "\n     Nombre: "+getNombre();
        aux+="\n     Cantidad de tareas: "+getCantidadDeTareas();
        aux+="\n    Suma de las notas de tareas: "+getSumaTareas();
        return aux;
    }
    
    
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidadDeTareas() {
        return cantidadDeTareas;
    }

    public double getPromedio(){
        return getSumaTareas()/getCantidadDeTareas();
    }
    
    public void setCantidadDeTareas(int cantidadDeTareas) {
        this.cantidadDeTareas = cantidadDeTareas;
    }

    public double getSumaTareas() {
        return sumaTareas;
    }

    public void setSumaTareas(double sumaTareas) {
        this.sumaTareas = sumaTareas;
    }
    
    

    
    
}
