/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ExamenCursos;

/**
 *
 * @author Fran
 */
public class Avanzado extends Curso{
    private String descripcion;

    public Avanzado(String descripcion, String nombre, String fecha, int M, double costoDeInscripción) {
        super(nombre, fecha, M, costoDeInscripción);
        this.descripcion = descripcion;
    }
    
    public String toString(){
        String aux = super.toString();
        aux+= "\nDatos del alumno con mejor rendimiento: "+this.alumnoMejorRendimiento().toString();
        return aux;
    }
    
    public Alumno alumnoMejorRendimiento(){
        double maxPromedio = 0;
        Alumno aux = null;
        for (int i =1; i<getDL();i++){
            if (this.encontrarAlumno(i).getPromedio()>maxPromedio){
                maxPromedio = this.encontrarAlumno(i).getPromedio();
                aux = this.encontrarAlumno(i);
            }
        }
        return aux;
    }
}
