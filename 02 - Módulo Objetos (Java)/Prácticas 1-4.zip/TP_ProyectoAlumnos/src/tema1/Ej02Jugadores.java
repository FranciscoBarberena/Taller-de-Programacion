
package tema1;

import PaqueteLectura.Lector;


public class Ej02Jugadores {

  
    public static void main(String[] args) {
        //Paso 2: Declarar la variable vector de double 
        double [] v;
        int df = 15;
        v = new double [df];
        //Paso 3: Crear el vector para 15 double 
        
        //Paso 4: Declarar indice y variables auxiliares a usar
        int i;
        double suma = 0;
        double cantCumple = 0;
        double promedio;
        //Paso 6: Ingresar 15 numeros (altura), cargarlos en el vector, ir calculando la suma de alturas
        for (i=0;i<15;i++){
              v[i] = Lector.leerDouble();
              suma+=v[i];
        }
        promedio = suma/df;
        System.out.println("Promedio alturas: " + promedio);
        //Paso 7: Calcular el promedio de alturas, informarlo
        
        //Paso 8: Recorrer el vector calculando lo pedido (cant. alturas que están por encima del promedio)
        for (i=0;i<15;i++){
            if (v[i]> promedio)
              cantCumple+=1;
        }
        System.out.println("Cantidad de alturas mayor al promedio: "+cantCumple);
        //Paso 9: Informar la cantidad.
    }
    
}
