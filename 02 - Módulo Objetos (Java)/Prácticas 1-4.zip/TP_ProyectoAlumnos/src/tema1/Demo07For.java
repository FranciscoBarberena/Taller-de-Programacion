/*
Ejemplos uso for vistos en clase.

 */
package tema1;

/**
 *
 * @author vsanz
 */
import PaqueteLectura.GeneradorAleatorio;
public class Demo07For {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GeneradorAleatorio.iniciar(); 
         System.out.println("Primer for (RANDOM)");
         double i;
         for (i=GeneradorAleatorio.generarDouble(11); i<10; i = GeneradorAleatorio.generarDouble(11)){
              System.out.println("I vale: " + i);
         }
         System.out.println("----------------------");
         System.out.println("Segundo for");
         for(i=10; i>0; i--){
              System.out.println("I vale: " + i);
         }

    }
    
}
