/*
 - El dueño de un restaurante entrevista a cinco clientes y les pide que califiquen
(con puntaje de 1 a 10) los siguientes aspectos: (0) Atención al cliente (1) Calidad
de la comida (2) Precio (3) Ambiente.
Escriba un programa que lea desde teclado las calificaciones de los cinco clientes
para cada uno de los aspectos y almacene la información en una estructura. Luego
imprima la calificación promedio obtenida por cada aspecto.
 */
package tema1;
import PaqueteLectura.GeneradorAleatorio;
import PaqueteLectura.Lector;
/**
 *
 * @author Fran
 */
public class Ej05Restaruante {
    public static void main(String[] args) {
       GeneradorAleatorio.iniciar();
       int DC = 4;
       int DF = 5;
       int [][] matriz = new int [DF][DC];
       double [] promedios = new double [DC];
       String [] nombres = new String [DC];
       nombres[0] = "Atención al cliente";
       nombres[1] = "Calidad de la comida";
       nombres[2] = "Precio";
       nombres[3] = "Ambiente";
       int i,j;
       for (j=0;j<DC;j++)
           promedios[j]=0;
       for (i=0; i<DF;i++){
           for(j=0;j<DC;j++){
               System.out.print("Calificar "+nombres[j]+": ");
               matriz[i][j] = Lector.leerInt();
               promedios[j]+=matriz[i][j];
           }
       }
       for (j=0;j<DC;j++){
           promedios[j]=promedios[j]/DF;
           System.out.println("Calificacion promedio de "+nombres[j]+": "+promedios[j]);
       }
    }
    
}
