/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema1;
/* - Un edificio de oficinas está conformado por 8 pisos (1..8) y 4 oficinas por piso
(1..4). Realice un programa que permita informar la cantidad de personas que
concurrieron a cada oficina de cada piso. Para esto, simule la llegada de personas al
edificio de la siguiente manera: a cada persona se le pide el nro. de piso y nro. de
oficina a la cual quiere concurrir. La llegada de personas finaliza al indicar un nro.
de piso 9. Al finalizar la llegada de personas, informe lo pedido.*/
 import PaqueteLectura.GeneradorAleatorio;

public class Ej04Oficinas {
    public static void main(String[] args) {
    GeneradorAleatorio.iniciar();
    int DF = 8;
    int DC = 4;
    int [][] matriz = new int [DF][DC];
    int i,j;
    for (i=0;i<DF;i++){
        for (j=0;j<DC;j++){
            matriz[i][j]=0;
        }
    }
    boolean fin = false;
    while (! fin) {
        i = GeneradorAleatorio.generarInt(DF+1)+1;
        System.out.println("piso "+i);
        if (i>8) 
          fin=true;
        else { 
          j = GeneradorAleatorio.generarInt(DC)+1;
          System.out.println("oficina "+j);
          matriz[i-1][j-1]+=1;
        }
    }
    int iaux,jaux;
    for (i=0;i<DF;i++){
        System.out.println("--------------------------------------------------------- ");
        for (j=0;j<DC;j++){
            iaux=i+1;
            jaux=j+1;
            System.out.print("   | ("+iaux+", "+jaux+") "+ matriz[i][j]);
        }
     System.out.println();
    }
    }
}
