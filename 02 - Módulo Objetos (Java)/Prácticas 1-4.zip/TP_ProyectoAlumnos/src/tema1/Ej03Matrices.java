/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema1;

import PaqueteLectura.GeneradorAleatorio;
import PaqueteLectura.Lector;

public class Ej03Matrices {

    public static void main(String[] args) {
	    //Paso 2. iniciar el generador aleatorio     
	 GeneradorAleatorio.iniciar();
        //Paso 3. definir la matriz de enteros de 5x5 e iniciarla con nros. aleatorios 
    int [][] matriz = new int [5][5];
    int i,j;
    for (i=0;i<5;i++){
        for (j=0;j<5;j++){
            matriz[i][j]=GeneradorAleatorio.generarInt(50);
        }
    }
        //Paso 4. mostrar el contenido de la matriz en consola
    for (i=0;i<5;i++){
        for (j=0;j<5;j++){
            System.out.println(i+","+j+": "+matriz[i][j]);
        }
    }
    int suma =0;
        //Paso 5. calcular e informar la suma de los elementos de la fila 1
    for (j=0;j<5;j++){
        suma+=matriz[1][j];
    }
    System.out.println("Suma de los elementos de la fila 1: "+suma);
        //Paso 6. generar un vector de 5 posiciones donde cada posición j contiene la suma de los elementos de la columna j de la matriz. 
        //        Luego, imprima el vector.
        int [] v = new int [5];
        for (j=0;j<5;j++)
            v[j]=0;
        for (i=0;i<5;i++){
            for (j=0;j<5;j++)
                v[j]+= matriz[i][j];
        }
        for (j=0;j<5;j++)
            System.out.println("Columna "+j+": "+v[j]);
        //Paso 7. lea un valor entero e indique si se encuentra o no en la matriz. En caso de encontrarse indique su ubicación (fila y columna)
        //   y en caso contrario imprima "No se encontró el elemento".
        int valorABuscar = GeneradorAleatorio.generarInt(50);
        //int valorABuscar = Lector.leerInt(50); para leerlo
        int posF = -1;
        int posC = -1;
        boolean encontro = false;
        i=0;
        j=0;
        while ((! encontro) && (i<5)) {
            while ((! encontro) && (j<5)){
        if (matriz[i][j]== valorABuscar){
                    posF=i;
                    posC=j;
                    encontro=true;}
         else
         j+=1;
        }
         j=0;       
          i+=1;          
        }
        if (! encontro)
           System.out.println("No se encontró el elemento "+ valorABuscar);
        else System.out.println("El elemento " +valorABuscar + " está en la posición: "+posF+","+posC);
    }      
}
        
    
     
