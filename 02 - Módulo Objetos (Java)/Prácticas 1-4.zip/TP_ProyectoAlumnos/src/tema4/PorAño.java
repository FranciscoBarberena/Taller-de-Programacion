/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author Fran
 */
public class PorAño extends Reporte{

    public PorAño(Estacion estacion, int añoInicio, int cantAños) {
        super(estacion, añoInicio, cantAños);
    }
    
    
    
    public double calcularPromedio(int añoACalcular){
        int sumaAño =0;
        for (int i =1;i<13;i++)
            sumaAño+=this.buscarTemp(añoACalcular,i);
        return sumaAño/12;
    }
    
    public String toString(){
        String aux = super.toString();
        for (int i =getAñoInicio();i<getAñoInicio()+getCantAños();i++){
            aux += "\nAño "+(i)+": "+calcularPromedio(i)+" °C";
        }
        return aux;
    }
}
