/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author Fran
 */
public class Jugador extends Empleado {
    private int golesMetidos;
    private int partidosJugados;
    
    public Jugador(int goles,int partidos, String nombre, double sueldo, int antiguedad){
        super(sueldo,antiguedad,nombre);
        setPartidosJugados(partidos);
        setGolesMetidos(goles);
    }

    public int getGolesMetidos() {
        return golesMetidos;
    }

    public void setGolesMetidos(int golesMetidos) {
        this.golesMetidos = golesMetidos;
    }

    public int getPartidosJugados() {
        return partidosJugados;
    }

    public void setPartidosJugados(int partidosJugados) {
        this.partidosJugados = partidosJugados;
    }
    
    public String toString(){
        String aux = super.toString()+ "\nPartidos jugados: "+getPartidosJugados()+"\nGoles metidos: "+getGolesMetidos();
        return aux;
    }
    
    public double calcularSueldoACobrar(){
        double aux = super.calcularSueldoACobrar();
        if (calcularEfectividad()>0.5)
            aux+=getSueldo();
        return aux;
    }
    public double calcularEfectividad(){
        return getGolesMetidos()/getPartidosJugados();
    }
}
