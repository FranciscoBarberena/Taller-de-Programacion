/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author Fran
 */
public class PorMes extends Reporte{

    public PorMes(Estacion estacion, int añoInicio, int cantAños) {
        super(estacion, añoInicio, cantAños);
    }
    
    
    
    public double calcularPromedio(int mesACalcular){
        int sumaMes =0;
        for (int i =this.getAñoInicio();i<this.getCantAños()+this.getAñoInicio();i++)
            sumaMes+=this.buscarTemp(i,mesACalcular);
        return sumaMes/getCantAños();
    }
    
    public String toString(){
        String aux = super.toString();
        for (int i =1;i<13;i++){
            aux += "\nMes "+(i)+": "+calcularPromedio(i)+" °C";
        }
        return aux;
    }
    
    
}
