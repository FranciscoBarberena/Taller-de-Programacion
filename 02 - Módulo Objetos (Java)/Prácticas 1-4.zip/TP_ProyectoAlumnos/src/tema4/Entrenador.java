/*
   Para los entrenadores: se adiciona un plus por campeonatos ganados (5000$ si ha
    ganado entre 1 y 4 campeonatos; $30.000 si ha ganado entre 5 y 10 campeonatos;
    50.000$ si ha ganado más de 10 campeonatos).

 */
package tema4;

/**
 *
 * @author Fran
 */
public class Entrenador extends Empleado {
    private int cantCampeonatos;

    public Entrenador(int unaCantCamp, double unSueldo, int unaAntiguedad,String unNombre){
        super(unSueldo,unaAntiguedad,unNombre);
        setCantCampeonatos(unaCantCamp);
    }
    
    private double calcularPlus(){
        double plus;
        if (getCantCampeonatos()==0)
            plus = 0;
        else if (getCantCampeonatos()>1 && getCantCampeonatos()<4)
            plus = 5000;
        else if (getCantCampeonatos()>4 && getCantCampeonatos()<10)
            plus =30000;
        else plus = 50000;
        return plus;
    }
    
    public int getCantCampeonatos() {
        return cantCampeonatos;
    }

    public void setCantCampeonatos(int cantCampeonatos) {
        this.cantCampeonatos = cantCampeonatos;
    }
    
    public String toString(){
        String aux;
        aux = super.toString() + "\nCantidad de campeonatos: "+ getCantCampeonatos();
        return aux;
    }
    
    public double calcularSueldoACobrar(){
        double plus;
        plus = super.calcularSueldoACobrar();
        if (getCantCampeonatos()==0)
            plus += 0;
        else if (getCantCampeonatos()>1 && getCantCampeonatos()<4)
            plus += 5000;
        else if (getCantCampeonatos()>4 && getCantCampeonatos()<10)
            plus +=30000;
        else plus += 50000;
        return plus;
    }
    public double calcularEfectividad(){
        double n = (double)getCantCampeonatos()/ getAntiguedad(); 
        return n;
    }
    
}
