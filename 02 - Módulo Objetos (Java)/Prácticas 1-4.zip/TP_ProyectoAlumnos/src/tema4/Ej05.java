/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author Fran
 */
public class Ej05 {
    
    public static void main(String[] args) {
    Dibujo d = new Dibujo("un dibujo");
    Cuadrado c1 = new Cuadrado(10,"Violeta","Rosa");
    Rectangulo r= new Rectangulo(20,10,"Azul","Celeste");
    Cuadrado c2= new Cuadrado(30,"Rojo","Naranja");
    d.agregar (c1);
    System.out.println("CANT GUARDADAS: "+d.getGuardadas());
    d.agregar (r);
    System.out.println("CANT GUARDADAS: "+d.getGuardadas());
    d.agregar (c2);
    System.out.println("CANT GUARDADAS: "+d.getGuardadas());
    d.mostrar();
    }
    
}
