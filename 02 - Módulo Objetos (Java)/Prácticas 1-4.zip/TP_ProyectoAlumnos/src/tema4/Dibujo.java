/*
5 A- Queremos representar dibujos. Un dibujo guarda su título y las figuras
que lo componen (círculos, triángulos, cuadrados, rectángulos, etc). Piense,
con lo visto hasta ahora (no es necesario implementar):

i- ¿Dónde almacenará las figuras que componen el dibujo?. ¿Cuántas
estructuras se necesitarán?.
ii- ¿Cómo agregará las distintas figuras al dibujo?. ¿Cuántos métodos agregar
necesita implementar?
iii- ¿Qué problema surge a medida que aumentan las posibles figuras en la
jerarquía?
Título: Un granadero

B- Implemente la clase Dibujo usando un array genérico de Figuras. Dicho array puede
guardar objetos creados a partir de cualquier subclase de Figura. Siga el molde mostrado.
 */
package tema4;

/**
 *
 * @author Fran
 */
public class Dibujo {

    private String titulo;
    private Figura [] vector;
    private int guardadas = 0;
    private int capacidadMaxima=10;
//inicia el dibujo, sin figuras
    public Dibujo (String titulo){
        setTitulo(titulo);
        vector = new Figura[capacidadMaxima];
    }
//agrega la figura al dibujo (un agregar por cada tipo de figura?? REPETICION DE CODIGO)
   public boolean agregar (Figura f){
      if (!estaLleno()){
        vector[getGuardadas()] = f;
        System.out.println("la figura "+
        f.toString() +
        " se ha guardado");
        setGuardadas(getGuardadas()+1);
        return true;
    } else return false;
   }
    
  /*  public boolean agregar(Cuadrado c){
    if (!estaLleno()){
        
        vector[getGuardadas()] = new Cuadrado(c.getLado(),c.getColorRelleno(),c.getColorLinea());
        vector[getGuardadas()] = c;
        System.out.println("la figura "+
        c.toString() +
        " se ha guardado");
        setGuardadas(getGuardadas()+1);
        return true;
    } else return false;
    }
    public boolean agregar(Rectangulo r){
    if (!estaLleno()){
        vector[getGuardadas()] = new Rectangulo(r.getBase(),r.getAltura(),r.getColorRelleno(),r.getColorLinea());
        vector[getGuardadas()] = r;
        System.out.println("la figura "+
        r.toString() +
        " se ha guardado");
        setGuardadas(getGuardadas()+1);
        return true;
    } else return false;
    }
    public boolean agregar(Circulo c){
    if (!estaLleno()){
        vector[getGuardadas()] = new Circulo(c.getColorRelleno(),c.getRadio(),c.getColorLinea());
        vector[getGuardadas()] =c;
        System.out.println("la figura "+
        c.toString() +
        " se ha guardado");
        setGuardadas(getGuardadas()+1);
        return true;
    } else return false;
    }
    public boolean agregar(Triangulo t){
    if (!estaLleno()){
        vector[getGuardadas()+1] = new Triangulo(t.getColorRelleno(),t.getColorLinea(),t.getLado1(),t.getLado2(),t.getLado3());
        vector[getGuardadas()+1] = t;
        System.out.println("la figura "+
        t.toString() +
        " se ha guardado");
        setGuardadas(getGuardadas()+1);
        return true;
    } else return false; 
    
    }*/
//calcula el área del dibujo:
//suma de las áreas de sus figuras
    public double calcularArea(){
        int i;
        int area = 0;
        for (i=0;i<getGuardadas();i++)
            area += vector[i].calcularArea();
        return area; 
    }
    
    private String getTitulo(){
        return titulo;
    }
    
    private void setTitulo(String titulo){
        this.titulo = titulo;
    }
    
    //imprime el título, representación
//de cada figura, y área del dibujo
    public void mostrar(){
        System.out.println("Título: "+getTitulo());
        System.out.println("Figuras:");
        for (int i =0; i<getGuardadas();i++)
            System.out.println("Figura "+(i+1)+" \n"+vector[i].toString());
        System.out.println("Área del dibujo: "+this.calcularArea());
    }

    public boolean estaLleno() {
    return (guardadas == capacidadMaxima);
    }

    public int getGuardadas() {
        return guardadas;
    }
    
    

    private void setGuardadas(int guardadas) {
        this.guardadas = guardadas;
    }

    
}
