/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author Fran
 */
public class Ej03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PersonaT4 per = new PersonaT4("Don Nadie",20555774,59);
        Trabajador tra = new Trabajador("Carpintero","Don laburante",41855454,49);
        System.out.println("----Persona----\n"+per);
        System.out.println(per.toString());
        System.out.println("----Trabajador----\n"+tra);
        System.out.println(tra.toString());
    }
    
}
