/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema3;

/**
 *
 * @author Fran
 */
public class Autor {
    private String nombre;
    private String biografía;
    private String origen;

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public Autor() {
    }

    
    public String toString() {
        return "el/la autor/a de "+origen+", "+nombre + "("+biografía+")";
    }
    
    public Autor(String nombre, String biografía, String origen) {
        this.nombre = nombre;
        this.biografía = biografía;
        this.origen = origen;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getBiografía() {
        return biografía;
    }

    public void setBiografía(String biografía) {
        this.biografía = biografía;
    }

    
    
}
