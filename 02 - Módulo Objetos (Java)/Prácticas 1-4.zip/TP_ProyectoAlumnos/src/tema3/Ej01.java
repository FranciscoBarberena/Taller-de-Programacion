/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema3;
import PaqueteLectura.Lector;
/**
 *
 * @author Fran
 */
public class Ej01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Triangulo tri = new Triangulo();
        System.out.print("Ingresar un lado A: ");
        tri.setLadoA(Lector.leerDouble());
        System.out.print("Ingresar un lado B: ");
        tri.setLadoB(Lector.leerDouble());
        System.out.print("Ingresar un lado C: ");
        tri.setLadoC(Lector.leerDouble());
        System.out.print("Ingresar un color de relleno: ");
        tri.setColorRelleno(Lector.leerString());
        System.out.print("Ingresar un color de línea: ");
        tri.setColorLinea(Lector.leerString());
        System.out.println("Perímetro del triángulo: "+ tri.calcularPerimetro());
        System.out.println("Área del triángulo: "+ tri.calcularArea());
        
    }
    
}
