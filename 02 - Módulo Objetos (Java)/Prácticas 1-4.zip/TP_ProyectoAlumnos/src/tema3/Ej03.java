/*
3-A- Defina una clase para representar estantes. Un estante almacena a lo sumo 20 libros.
Implemente un constructor que permita iniciar el estante sin libros. Provea métodos para:
(i) devolver la cantidad de libros almacenados (ii) devolver si el estante está lleno
(iii) agregar un libro al estante (iv) devolver el libro con un título particular que se recibe.
B- Realice un programa que instancie un estante. Cargue varios libros. A partir del estante,
busque e informe el autor del libro “Mujercitas”.
C- Piense: ¿Qué modificaría en la clase definida para ahora permitir estantes que
almacenen como máximo N libros? ¿Cómo instanciaría el estante? (que el valor de DF no se setee por defecto?)

 */
package tema3;

/**
 *
 * @author Fran
 */
public class Ej03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Estante vector = new Estante();
        Libro libroAux;
        for (int i=0;i<15;i++){
            libroAux = new Libro ("Libro "+i);
            vector.addBook(libroAux);
        }
        Autor autorAux = new Autor ("Juana","gran escritora","Alemania");
        libroAux = new Libro ("Mujercitas","Santillana",2025,autorAux,"51661",500);
        vector.addBook(libroAux);
        for (int i=0;i<vector.getDL();i++){
            System.out.println(vector.getEstante()[i].getTitulo());
        }
        if (!(vector.findBook("Mujercitas")==null))
            System.out.println("La autora de mujercitas fue: "+vector.findBook("Mujercitas").getPrimerAutor().toString());
        else System.out.println("No está mujercitas");
    }
    
}
