/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema3;

import PaqueteLectura.GeneradorAleatorio;
import tema2.Persona;

/**
 *
 * @author Fran
 */
public class Hotel {
    private int N;
    private Habitacion[] hotel;
    

   
    
    public Hotel(int n){

        this.N = n;
        hotel = new Habitacion[N];
        for (int i=0;i<getCantHabitaciones();i++){ //Inicializar habitaciones
           hotel[i] = new Habitacion((GeneradorAleatorio.generarDouble(6000)+2000));
       }
    }

    public int getCantHabitaciones() {
        return N;
    }


    public Habitacion[] getHotel() {
        return hotel;
    }

    
   public boolean addCliente (Persona C, int X){
       if (!hotel[X].isOcupada()){
           hotel[X].agregarCliente(C);
           return true;
       }
       return false;
       
   }
   
   public void raisePrices(double monto){
       for (int i =0;i<N;i++){
           hotel[i].aumentarPrecio(monto);
       }
   }
   public String toString(){ //PREGUNTAR TO STRING DE OBJETOS DENTRO DE OBJETOS
       String aux="";
       for (int i=0;i<N;i++){
           aux+=hotel[i].toString(i);
       }
       return aux;
   }
    
}
