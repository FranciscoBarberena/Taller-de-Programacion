/*
3-A- Defina una clase para representar estantes. Un estante almacena a lo sumo 20 libros.
Implemente un constructor que permita iniciar el estante sin libros. Provea métodos para:
(i) devolver la cantidad de libros almacenados (ii) devolver si el estante está lleno
(iii) agregar un libro al estante (iv) devolver el libro con un título particular que se recibe.
B- Realice un programa que instancie un estante. Cargue varios libros. A partir del estante,
busque e informe el autor del libro “Mujercitas”.
C- Piense: ¿Qué modificaría en la clase definida para ahora permitir estantes que
almacenen como máximo N libros? ¿Cómo instanciaría el estante?
 */
package tema3;

/**
 *
 * @author Fran
 */
public class Estante {
    private int DL =0;
    private int DF= 20;
    private Libro [] estante;

    public Estante() {
        estante = new Libro [DF];
    }

    public Libro[] getEstante() {
        return estante;
    }
    public int getDL(){
        return DL;
    }
    public int getDF(){
        return DF;
    }
    public boolean isFull(){
        if (DL==DF)
            return true;
        else return false;
    }
    
    public void addBook(Libro unLibro){
        estante[DL] = new Libro(unLibro.getTitulo(),unLibro.getEditorial(),unLibro.getAñoEdicion(),unLibro.getPrimerAutor(),unLibro.getISBN(),unLibro.getPrecio());
        this.DL++;
    }
    
    public Libro findBook (String unTitulo){
        int i =0;
        while (i<DL&&(!(estante[i].getTitulo().equals(unTitulo)))&& i<DL){
            i++;
        }
        if (i<DL && (estante[i].getTitulo().equals(unTitulo)))
           return estante[i];
        else return null;
    }
    
    
}
