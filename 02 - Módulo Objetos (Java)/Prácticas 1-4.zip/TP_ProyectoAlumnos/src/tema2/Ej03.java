package tema2;

/*
 3- Se realizará un casting para un programa de TV. El casting durará a lo sumo 5 días y en
cada día se entrevistarán a 8 personas en distinto turno.
a) Simular el proceso de inscripción de personas al casting. A cada persona se le pide
nombre, DNI y edad y se la debe asignar en un día y turno de la siguiente manera: las
personas primero completan el primer día en turnos sucesivos, luego el segundo día y así
siguiendo. La inscripción finaliza al llegar una persona con nombre “ZZZ” o al cubrirse los
40 cupos de casting.
Una vez finalizada la inscripción:
b) Informar para cada día y turno asignado, el nombre de la persona a entrevistar.
NOTA: utilizar la clase Persona. Pensar en la estructura de datos a utilizar. Para comparar
Strings use el método equals.
 */
import PaqueteLectura.Lector;
import PaqueteLectura.GeneradorAleatorio;
/**
 *
 * @author Fran
 */
public class Ej03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int DF = 5;
        int DC =8;
        int DL = 0;
        GeneradorAleatorio.iniciar();
        Persona[][] matriz = new Persona [DF][DC];
        Persona per = new Persona();
        per.setNombre(Lector.leerString());
        while((!per.getNombre().equals("ZZZ")) && (DL<40)){
            matriz [DL/DC][DL%DC] = new Persona(); //HAY QUE HACERLE NEW A LOS ELEMENTOS DE UN VECTOR DE OBJETOS!}
            matriz[DL/DC][DL%DC].setDNI(GeneradorAleatorio.generarInt(5000)); //se pueden asignar objetos sin asignar direcciones???
            matriz[DL/DC][DL%DC].setEdad(GeneradorAleatorio.generarInt(30)+16);
            matriz[DL/DC][DL%DC].setNombre(per.getNombre());
            DL+=1;
            if (DL<40) //Solo leo el siguiente si queda espacio
                per.setNombre(Lector.leerString());
        }
        
        int i;
        for (i=0;i<DL;i++){
            System.out.println("Habrá que entrevistar a "+ matriz[i/DC][i%DC].getNombre()+" en el dia "+ (i/DC+1) + " durante el turno "+ (i%DC+1));}
      
        
        
        
    }
    
}
