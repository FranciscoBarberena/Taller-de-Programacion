
package tema2;



 
import PaqueteLectura.Lector;


public class Ej01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Persona p3;
        p3 = new Persona();
        System.out.print("Ingresar DNI: ");
        p3.setDNI(Lector.leerInt());
        System.out.print("Ingresar nombre: ");
        p3.setNombre(Lector.leerString());
        System.out.print("Ingresar edad: ");
        p3.setEdad(Lector.leerInt());
        System.out.println(p3.toString());
    }
    
}
