package tema2;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Fran
 */
public class ImprimirAuto {
    public static void main(String[] args) {
    Auto auto1;
    auto1 = new Auto();
    auto1.setColor("rojo");
    auto1.setMarca("BMW");
    auto1.setVelocidad(80.8);
    System.out.println(auto1.autoQueHabla());
}}
