package tema2;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Fran
 */
public class Auto {
    private String color;
    private double velocidad;
    private String marca;


    public Auto (String unColor, double unaVelocidad, String unaMarca){
        color = unColor;
        velocidad = unaVelocidad;
        marca = unaMarca;
}
public Auto (){
    
}
public void setColor(String unColor){
    color = unColor;
}
public void setMarca(String unaMarca){
    marca = unaMarca;
}
public void setVelocidad(double unaVelocidad){
    velocidad = unaVelocidad;
}
public String autoQueHabla(){
    String devuelve;
    devuelve = ("Soy un auto de color " + color +" con una velocidad de "+velocidad+" km/h y cuya marca es " + marca+".");
    return devuelve;
}
}
