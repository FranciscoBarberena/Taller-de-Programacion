/*
Utilizando la clase Persona. Realice un programa que almacene en un vector a lo sumo 
15 personas. La información (nombre, DNI, edad) se debe generar aleatoriamente hasta 
obtener edad 0. Luego de almacenar la información: -  Informe la cantidad de personas mayores de 65 años. - 
Muestre la representación de la persona con menor DNI.
 */
package tema2;

import PaqueteLectura.Lector;
import PaqueteLectura.GeneradorAleatorio;
import sun.security.pkcs11.P11Util;


/**
 *
 * @author Alumno
 */
public class Ej02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GeneradorAleatorio.iniciar();
        int dimF = 15;
        Persona[] vector = new Persona[dimF];
        int DL =0;
        int i;
        Persona aux = new Persona();
        aux.setNombre(GeneradorAleatorio.generarString(10));
        aux.setEdad(GeneradorAleatorio.generarInt(67));
        aux.setDNI(GeneradorAleatorio.generarInt(5000));
      
        while ((DL<dimF-1) && (aux.getEdad()!=0)){
            vector[DL]=aux;
            DL+=1;
            aux = new Persona();
            aux.setNombre(GeneradorAleatorio.generarString(10));
            aux.setEdad(GeneradorAleatorio.generarInt(67));
            aux.setDNI(GeneradorAleatorio.generarInt(5000)+1000);
        }
        i=0;
        while (i<DL){
            System.out.println(vector[i].toString());
            i+=1;
        }
        
        int cantMayores = 0;
        i=0;
        
        int posMax = -1;
        int dniMax = 0;
        while(i<DL){
            if (vector[i].getEdad()>65)
                    cantMayores +=1;
            if (vector[i].getDNI()>dniMax){
                posMax=i;
                dniMax=vector[i].getDNI();
            }
            i+=1;
        }
        System.out.println("Cantidad de mayores a 65 años: "+cantMayores);
        System.out.println("La persona con DNI maximo fue "+ vector[posMax].toString());
        
        
        
        
        
    }
    
}
