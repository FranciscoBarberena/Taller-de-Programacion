package tema2;

/*
 4- Sobre un nuevo programa, modifique el ejercicio anterior para considerar que:  
a) Durante el proceso de inscripción se pida a cada persona sus datos (nombre, DNI, edad) 
y el día en que se quiere presentar al casting. La persona debe ser inscripta en ese día, en el 
siguiente turno disponible. En caso de no existir un turno en ese día, informe la situación.       
La inscripción finaliza al llegar una persona con nombre “ZZZ” o al cubrirse los 40 cupos 
de casting. 
Una vez finalizada la inscripción: 
b) Informar para cada día: la cantidad de inscriptos al casting ese día y el nombre de la 
persona a entrevistar en cada turno asignado.
 */
import PaqueteLectura.Lector;
import PaqueteLectura.GeneradorAleatorio;
/**
 *
 * @author Fran
 */
public class Ej04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int DF = 5;
        int i;
        int DL =0;
        int DC =8;
        int [] vectorDL = new int [DF];
        int diaDeseado;
        for (i=0;i<DF;i++) //iniciar dl
            vectorDL[i] = 0;
        GeneradorAleatorio.iniciar();
        Persona[][] matriz = new Persona [DF][DC];
        Persona per = new Persona();
        System.out.print("Ingresar nombre: ");
        per.setNombre(Lector.leerString());
        
        while(!per.getNombre().equals("ZZZ") && (DL<40)){
            System.out.print("Ingresar dia en el que se quiere ir: ");
                diaDeseado = Lector.leerInt()-1;
            if (vectorDL[diaDeseado]==8){
                System.out.println("El dia ingresado está lleno");
            }
            else {
                matriz [diaDeseado][vectorDL[diaDeseado]] = new Persona(per.getNombre(),GeneradorAleatorio.generarInt(5000),GeneradorAleatorio.generarInt(30)+16); //HAY QUE HACERLE NEW A LOS ELEMENTOS DE UN VECTOR DE OBJETOS!}
                /*
                matriz [diaDeseado-1][DL%DC] = new Persona(); //HAY QUE HACERLE NEW A LOS ELEMENTOS DE UN VECTOR DE OBJETOS!}
                matriz[diaDeseado-1][DL%DC].setDNI(GeneradorAleatorio.generarInt(5000)); 
                matriz[diaDeseado-1][DL%DC].setEdad(GeneradorAleatorio.generarInt(30)+16);
                matriz[diaDeseado-1][DL%DC].setNombre(per.getNombre());
                */
                vectorDL[diaDeseado]++;
                DL+=1;
            }
            System.out.print("Ingresar nombre: ");
            per.setNombre(Lector.leerString());
            
        }
        int j;
        
        for (i=0;i<DF;i++){
            System.out.println("DIA "+(i+1));
            System.out.println("Cantidad de inscriptos: "+vectorDL[i]);
            for (j=0;j<vectorDL[i];j++){
                System.out.println("Habrá que entrevistar a "+ matriz[i][j].getNombre()+" en el dia "+ (i+1) + " durante el turno "+ (j+1));
            }
      
        }
        
        
    }
    
}
