/*
1- La UNLP desea administrar sus proyectos, investigadores y subsidios. Un proyecto
tiene: nombre, código, nombre completo del director y los investigadores que participan
en el proyecto (50 como máximo). De cada investigador se tiene: nombre completo,
categoría (1 a 5) y especialidad. Además, cualquier investigador puede pedir hasta un
máximo de 5 subsidios. De cada subsidio se conoce: el monto pedido, el motivo y si fue
otorgado o no.

CLASES:  proyectos, investigadores y subsidios

i) Implemente el modelo de clases teniendo en cuenta:
    a. Un proyecto sólo debería poder construirse con el nombre, código, nombre del
    director.
    b. Un investigador sólo debería poder construirse con nombre, categoría y
    especialidad.
    c. Un subsidio sólo debería poder construirse con el monto pedido y el motivo.
    Un subsidio siempre se crea en estado no-otorgado.

ii) Implemente los métodos necesarios (en las clases donde corresponda) que permitan:
    a. void agregarInvestigador(Investigador unInvestigador);
    // agregar un investigador al proyecto.
    b. void agregarSubsidio(Subsidio unSubsidio);
    // agregar un subsidio al investigador.
    c. double dineroTotalOtorgado();
    //devolver el monto total otorgado en subsidios del proyecto (tener en cuenta
    todos los subsidios otorgados de todos los investigadores)
    d. void otorgarTodos(String nombre_completo);
    //otorgar todos los subsidios no-otorgados del investigador llamado
    nombre_completo
    e. String toString();
    // devolver un string con: nombre del proyecto, código, nombre del director, el
    total de dinero otorgado del proyecto y la siguiente información de cada
    investigador: nombre, categoría, especialidad, y el total de dinero de sus
    subsidios otorgados.

iii) Escriba un programa que instancie un proyecto con tres investigadores. Agregue dos
subsidios a cada investigador y otorgue los subsidios de uno de ellos. Luego imprima
todos los datos del proyecto en pantalla.
 */
package Examen;

/**
 *
 * @author Fran
 */
public class Proyecto {
    private String nombre;
    private int code;
    private String nombreDirector;
    private Investigador[] vector;
    private int DL = 0;
    private int capacidadMaxima = 50;

    public Proyecto(String nombre, int code, String nombreDirector) {
        this.nombre = nombre;
        this.code = code;
        this.nombreDirector = nombreDirector;
        vector = new Investigador[capacidadMaxima];
    }
    
    public void agregarInvestigador(Investigador unInvestigador){ //si o si void????
        if(!estaLleno()){
            vector[DL]=unInvestigador;
            DL++;
            
        }
    }
    /*c. double dineroTotalOtorgado();
    //devolver el monto total otorgado en subsidios del proyecto (tener en cuenta
    todos los subsidios otorgados de todos los investigadores)*/
    
    public double dineroTotalOtorgado(){
        int aux = 0;
        for (int i=0;i<DL;i++){
            aux+= vector[i].dineroTotalOtorgado();
        }
        return aux;
    }
   /* d. void otorgarTodos(String nombre_completo);
    //otorgar todos los subsidios no-otorgados del investigador llamado
    nombre_completo*/
    
    public void otorgarTodos(String nombreCompleto){
        int i =0;
        while (( i < DL) && (!vector[i].getNombre().equals(nombreCompleto)))
            i++;
        if ((i<DL) && (vector[i].getNombre().equals(nombreCompleto)))
            vector[i].otorgarTodos();
        
    }
    
 
    
    public String toString(){
        String aux="";
        aux+="Nombre del proyecto: "+getNombre();
        aux+="\nCodigo del proyecto: "+getCode();
        aux+="\nNombre del director: "+ getNombreDirector();
        int i;
        if(DL>0){
            for (i=0; i<DL;i++)
                aux+=vector[i].toString();
            aux+="\nDinero otorgado al proyecto: $"+this.dineroTotalOtorgado();
        }
        else aux+="\nProyecto sin investigadores ni dinero";
        return aux;
        
    }
    
    
    
    private boolean estaLleno(){
        if (DL == capacidadMaxima)
            return true;
        else return false;
    
}

    private String getNombre() {
        return nombre;
    }

    private int getCode() {
        return code;
    }

    private String getNombreDirector() {
        return nombreDirector;
    }
    
}

