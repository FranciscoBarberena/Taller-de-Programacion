package Examen;

/*
1- La UNLP desea administrar sus proyectos, investigadores y subsidios. Un proyecto
tiene: nombre, código, nombre completo del director y los investigadores que participan
en el proyecto (50 como máximo). De cada investigador se tiene: nombre completo,
categoría (1 a 5) y especialidad. Además, cualquier investigador puede pedir hasta un
máximo de 5 subsidios. De cada subsidio se conoce: el monto pedido, el motivo y si fue
otorgado o no.

CLASES:  proyectos, investigadores y subsidios

i) Implemente el modelo de clases teniendo en cuenta:
    a. Un proyecto sólo debería poder construirse con el nombre, código, nombre del
    director.
    b. Un investigador sólo debería poder construirse con nombre, categoría y
    especialidad.
    c. Un subsidio sólo debería poder construirse con el monto pedido y el motivo.
    Un subsidio siempre se crea en estado no-otorgado.

ii) Implemente los métodos necesarios (en las clases donde corresponda) que permitan:
    a. void agregarInvestigador(Investigador unInvestigador);
    // agregar un investigador al proyecto.
    b. void agregarSubsidio(Subsidio unSubsidio);
    // agregar un subsidio al investigador.
    c. double dineroTotalOtorgado();
    //devolver el monto total otorgado en subsidios del proyecto (tener en cuenta
    todos los subsidios otorgados de todos los investigadores)
    d. void otorgarTodos(String nombre_completo);
    //otorgar todos los subsidios no-otorgados del investigador llamado
    nombre_completo
    e. String toString();
    // devolver un string con: nombre del proyecto, código, nombre del director, el
    total de dinero otorgado del proyecto y la siguiente información de cada
    investigador: nombre, categoría, especialidad, y el total de dinero de sus
    subsidios otorgados.

iii) Escriba un programa que instancie un proyecto con tres investigadores. Agregue dos
subsidios a cada investigador y otorgue los subsidios de uno de ellos. Luego imprima
todos los datos del proyecto en pantalla.
 */

/**
 *
 * @author Fran
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Proyecto p = new Proyecto ("Evolución",1568,"Mr. Director");
        Investigador i1 = new Investigador("Inv1",2,"Buscacador");
        Investigador i2 = new Investigador("Inv2",1,"Analista");
        Investigador i3 = new Investigador("Inv3",5,"Administrador");
        p.agregarInvestigador(i1);
        p.agregarInvestigador(i2);
        p.agregarInvestigador(i3);
        Subsidio s1 = new Subsidio(500,"Falta plata");
        Subsidio s2 = new Subsidio(1500,"No alcanza");
        i1.agregarSubsidio(s1);
        i1.agregarSubsidio(s2);
        Subsidio s3 = new Subsidio(111500,"Estamos en deuda");
        Subsidio s4 = new Subsidio(15000,"Sueldos");
        i2.agregarSubsidio(s3);
        i2.agregarSubsidio(s4);
        Subsidio s5 = new Subsidio(999,"Falta equipamiento");
        Subsidio s6 = new Subsidio(1200,"Viáticos");
        i3.agregarSubsidio(s5);
        i3.agregarSubsidio(s6);
        p.otorgarTodos("Inv3");
        System.out.println(p.toString());
    }
    
}
