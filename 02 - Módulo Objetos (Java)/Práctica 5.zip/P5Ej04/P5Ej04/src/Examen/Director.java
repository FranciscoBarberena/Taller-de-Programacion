/*
 Superclase abstracta: coro (nombre, director)
Subclases: CoroSemicircular (nombre, director, vector de coristas)
          CoroPorHileras(nombre, director, matriz cuadrada de coristas)

Superclase abstracta: Persona (dni, edad)
Subclases: Director(dni, edad, antiguedad)
            Corista (dni, edad, tono fundamental)
 */
package Examen;

/**
 *
 * @author Fran
 */
public class Director extends Persona{
    private int antiguedad;

    public Director(int antiguedad, String nombre, int DNI) {
        super(nombre, DNI);
        this.antiguedad = antiguedad;
    }


    public String toString() {
        String aux = super.toString();
        aux+="\nAntiguedad: "+antiguedad;
        return aux;
    }
    
    
    
    
}
