/*
 4- Una escuela de música arma coros para participar de ciertos eventos. Los coros poseen
un nombre y están formados por un director y una serie de coristas. Del director se
conoce el nombre, DNI, edad y la antigüedad (un número entero). De los coristas se conoce
el nombre, DNI, edad y el tono fundamental (un número entero). Asimismo, hay dos tipos
de coros: coro semicircular en el que los coristas se colocan en el escenario uno al lado
del otro y coro por hileras donde los coristas se organizan en filas de igual dimensión.

a. Implemente las clases necesarias teniendo en cuenta que los coros deberían crearse
con un director y sin ningún corista, pero sí sabiendo las dimensiones del coro.

 */
package Examen;

/**
 Superclase abstracta: coro (nombre, director)
Subclases: CoroSemicircular (nombre, director, vector de coristas)
          CoroPorHileras(nombre, director, matriz cuadrada de coristas)
          *  devolver la representación de un coro formada por el nombre del coro, todos
    los datos del director y todos los datos de todos los coristas.
 * @author Fran
 */
public abstract class Coro {
    private String nombre;
    private Director direct;
    private int dimFisica;
    private int guardadas;

    public Coro(String nombre, Director direct, int dimFisica) {
        this.nombre = nombre;
        this.direct = direct;
        this.dimFisica = dimFisica;
    }

    public int getGuardadas() {
        return guardadas;
    }

    public void setGuardadas(int guardadas) { //esto deberia ser privado????)
        this.guardadas = guardadas;
    }
    
    
    
    public String toString(){
        String aux ="\nNombre del coro: "+ nombre;
        aux+="\nDatos del director: "+direct.toString();
        return aux;
    }
    
    public boolean estaLleno(){
        return guardadas == dimFisica;
    }


    
    public int getDimFisica() {
        return dimFisica;
    }
    
    
    public abstract boolean agregarCorista(Corista c);
    public abstract boolean estaBienFormado();
        

    
    
}
