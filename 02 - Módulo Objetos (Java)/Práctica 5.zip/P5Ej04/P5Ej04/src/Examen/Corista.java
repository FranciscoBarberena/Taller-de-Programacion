/*
 Superclase abstracta: coro (nombre, director)
Subclases: CoroSemicircular (nombre, director, vector de coristas)
          CoroPorHileras(nombre, director, matriz cuadrada de coristas)

Superclase abstracta: Persona (dni, edad)
Subclases: Director(dni, edad, antiguedad)
            Corista (dni, edad, tono fundamental)
 */
package Examen;

/**
 *
 * @author Fran
 */
public class Corista extends Persona{
    private int tonoFundamental;

    public Corista(int tonoFundamental, String nombre, int DNI) {
        super(nombre, DNI);
        this.tonoFundamental = tonoFundamental;
    }

    public String toString(){
        String aux= super.toString();
        aux+="\nTono fundamental: "+tonoFundamental;
        return aux;
    }
    
    public int getTonoFundamental() {
        return tonoFundamental;
    }
    
    
}
