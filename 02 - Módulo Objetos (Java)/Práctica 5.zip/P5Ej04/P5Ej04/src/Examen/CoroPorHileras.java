/*
 Superclase abstracta: coro (nombre, director)
Subclases: CoroSemicircular (nombre, director, vector de coristas)
          CoroPorHileras(nombre, director, matriz cuadrada de coristas)

Superclase abstracta: Persona (dni, edad)
Subclases: Director(dni, edad, antiguedad)
            Corista (dni, edad, tono fundamental)
 */
package Examen;

/**
 *
 * @author Fran
 */
public class CoroPorHileras extends Coro{
    private Corista[][] matriz;
    private int dimColumnas;

    public CoroPorHileras(int dimFisica, String nombre, Director direct) {
        super(nombre, direct,dimFisica);
        this.setDimColumnas((int)Math.sqrt(dimFisica));
        matriz = new Corista[dimColumnas][dimColumnas];
    }

    private void setDimColumnas(int dimColumnas) {
        this.dimColumnas = dimColumnas;
    }
    
    public boolean agregarCorista(Corista c){
        if (!this.estaLleno()){
            matriz[this.getGuardadas()/dimColumnas][this.getGuardadas()%dimColumnas] = c;
            this.setGuardadas(getGuardadas()+1);
            return true;
        } else return false;
    }
    
    /*o En el caso del coro por hileras, todos los miembros de una misma hilera
        tienen el mismo tono fundamental y además todos los primeros
        miembros de cada hilera están ordenados de mayor a menor en cuanto
        a tono fundamental.*/
    
    private boolean hileraCumple(int i){
        int j =0;
        boolean seguir = true;
        while((j <getDimColumnas()-1) && (seguir)){
            if (matriz[j][i].getTonoFundamental() == matriz[j+1][i].getTonoFundamental())
                j++;
            else seguir = false;
        }
        return seguir;
    }
    
    private boolean hilerasCumplen(){
        int i = 0;
        boolean seguir = true;
        while((i<getDimColumnas()) && (seguir)){
            seguir = hileraCumple(i);
            i++;
        }
        return seguir;
    }
    
    private boolean primerosMiembrosCumplen(){
        int i =0;
        boolean seguir = true;
        while ((i<getDimColumnas()-1)&& (seguir)){
            if (matriz[0][i].getTonoFundamental()>matriz[0][i+1].getTonoFundamental())
                i++;
            else seguir = false;
        }
        return seguir;    
    }
    
    public boolean estaBienFormado(){
        if ((this.hilerasCumplen()) && (this.primerosMiembrosCumplen()))
            return true;
            else return false;
    }

    private int getDimColumnas() {
        return dimColumnas;
    }
    
    public String toString(){
        String aux = super.toString();
        aux+="\nDATOS DE LOS CORISTAS DE LA MATRIZ: ";
        int i =0;
        while (i<getGuardadas()){
            aux+="\nCorista fila"+(i/getGuardadas()+1)+", columna"+(i%getGuardadas()+1)+": "+matriz[i/getDimColumnas()][i%getDimColumnas()].toString();
            i++;
        }
        return aux;
    }
    
    
    
}
