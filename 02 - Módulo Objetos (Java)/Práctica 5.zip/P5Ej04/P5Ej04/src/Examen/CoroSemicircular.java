/*
Superclase abstracta: coro (nombre, director)
Subclases: CoroSemicircular (nombre, director, vector de coristas)
          CoroPorHileras(nombre, director, matriz cuadrada de coristas)

Superclase abstracta: Persona (dni, edad)
Subclases: Director(dni, edad, antiguedad)
            Corista (dni, edad, tono fundamental)

 */
package Examen;

/**
 *
 * @author Fran
 */
public class CoroSemicircular extends Coro{
    private Corista[] vector;

    public CoroSemicircular(int dimFisica, String nombre, Director direct) {
        super(nombre, direct, dimFisica);
        vector= new Corista[dimFisica];
    }
    
    public boolean agregarCorista (Corista C){
        if (!estaLleno()){
            vector[this.getGuardadas()]=C;
            this.setGuardadas(getGuardadas()+1);
            return true;
            
        } else return false;
    }
    /*o En el caso del coro semicircular, de izquierda a derecha los coristas
        están ordenados de mayor a menor en cuanto a tono fundamental.*/
    
    public boolean estaBienFormado(){
        int i = 0;
        boolean seguir = true;
        while((i<getDimFisica()-1) && (seguir)){
            if (vector[i].getTonoFundamental()>vector[i+1].getTonoFundamental())
                i++;
            else seguir = false;
        }
        return seguir;
    }
    
    public String toString(){
        String aux = super.toString();
        aux+="\nDATOS DE LOS CORISTAS DEL SEMICIRCULO: ";
        for (int i =0;i<getGuardadas();i++){
            aux+="\nCorista "+(i+1)+": "+vector[i].toString();
        }
        return aux;
    }
    
}
