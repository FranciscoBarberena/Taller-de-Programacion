package Examen;

/*
4- Una escuela de música arma coros para participar de ciertos eventos. Los coros poseen
un nombre y están formados por un director y una serie de coristas. Del director se
conoce el nombre, DNI, edad y la antigüedad (un número entero). De los coristas se conoce
el nombre, DNI, edad y el tono fundamental (un número entero). Asimismo, hay dos tipos
de coros: coro semicircular en el que los coristas se colocan en el escenario uno al lado
del otro y coro por hileras donde los coristas se organizan en filas de igual dimensión.

Superclase abstracta: coro (nombre, director)
Subclases: CoroSemicircular (nombre, director, vector de coristas)
          CoroPorHileras(nombre, director, matriz cuadrada de coristas)

Superclase abstracta: Persona (dni, edad)
Subclases: Director(dni, edad, antiguedad)
            Corista (dni, edad, tono fundamental)

a. Implemente las clases necesarias teniendo en cuenta que los coros deberían crearse
con un director y sin ningún corista, pero sí sabiendo las dimensiones del coro.

b. Implemente métodos (en las clases donde corresponda) que permitan:
     agregar un corista al coro.
        o En el coro semicircular los coristas se deben ir agregando de izquierda
        a derecha
        o En el coro por hileras los coristas se deben ir agregando de izquierda a
        derecha, completando la hilera antes de pasar a la siguiente.

     determinar si un coro está lleno o no. Devuelve true si el coro tiene a todos sus
    coristas asignados o false en caso contrario.

     determinar si un coro (se supone que está lleno) está bien formado. Un coro
    está bien formado si:

        o En el caso del coro semicircular, de izquierda a derecha los coristas
        están ordenados de mayor a menor en cuanto a tono fundamental.

        o En el caso del coro por hileras, todos los miembros de una misma hilera
        tienen el mismo tono fundamental y además todos los primeros
        miembros de cada hilera están ordenados de mayor a menor en cuanto
        a tono fundamental.

     devolver la representación de un coro formada por el nombre del coro, todos
    los datos del director y todos los datos de todos los coristas.

c. Escriba un programa que instancie un coro de cada tipo. Lea o bien la cantidad de
coristas (en el caso del coro semicircular) o la cantidad de hileras e integrantes por
hilera (en el caso del coro por hileras). Luego cree la cantidad de coristas necesarios,
leyendo sus datos, y almacenándolos en el coro. Finalmente imprima toda la
información de los coros indicando si están bien formados o no.

 */
import PaqueteLectura.Lector;
import PaqueteLectura.GeneradorAleatorio;
/**
 *
 * @author Fran
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GeneradorAleatorio.iniciar(); //donde instanciar directores???? conisgna dice que "el coro se crea con un director"
        System.out.print("Ingrese cantidad de coristas de coro semicircular: ");
        int df = Lector.leerInt();
        Director d1 = new Director(20,"Spilberg",18455788);
        CoroSemicircular semi = new CoroSemicircular (df,"Coro semicircularrr",d1);
        System.out.print("Ingrese cantidad de coristas de coro por hileras: ");
        int df2 = Lector.leerInt();
        Director d2 = new Director(25,"Fincher",184788);
        CoroPorHileras hil = new CoroPorHileras(df2,"Coro hilerasss",d2);
        int tonoAux;
        int dniAux;
        String nombreAux;
        Corista coristaAux;
        System.out.println("Llenar coro semicircular: ");
        for (int i = 0;i<df;i++){ //llenar coro semicircular
            System.out.print("Ingresar tono fundamental: "); //REPETICION DE CODIGO?????? Pero no se puede hacer en el constructor porque "el coro se crea sin coristas"
            tonoAux=Lector.leerInt();
            //System.out.print("Ingresar DNI: ");
            dniAux=GeneradorAleatorio.generarInt(5000)+1000;
            //System.out.print("Ingresar nombre: ");
            nombreAux=GeneradorAleatorio.generarString(10);
            coristaAux = new Corista(tonoAux,nombreAux,dniAux);
            semi.agregarCorista(coristaAux);
        }
        System.out.println("Llenar coro por hileras: ");
        for (int i = 0;i<df2;i++){ //llenar coro por hileras
            System.out.print("Ingresar tono fundamental: ");
            tonoAux=Lector.leerInt();
            //System.out.print("Ingresar DNI: ");
            dniAux=GeneradorAleatorio.generarInt(5000)+1000;
            //System.out.print("Ingresar nombre: ");
            nombreAux=GeneradorAleatorio.generarString(10);
            coristaAux = new Corista(tonoAux,nombreAux,dniAux);
            hil.agregarCorista(coristaAux);
        }
        
        System.out.println("El coro semicircular está bien formado? "+semi.estaBienFormado()+" Acá está su información: "+semi.toString());
        System.out.println("------------------------------------------");
        System.out.println("El coro por hileras está bien formado? "+hil.estaBienFormado()+"!. Acá está su información: "+hil.toString());
    }
    
}
