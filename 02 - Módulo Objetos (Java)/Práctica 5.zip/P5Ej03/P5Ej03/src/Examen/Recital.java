/*
/*

3- Un productor musical desea administrar los recitales que organiza, que pueden ser:
eventos ocasionales y giras.

Clase abstracta: recital (nombreBanda,listaTemas)
Subclases: EventoOcasional (motivo,nombreContratante,diaEvento) y Gira (nombreGira, fechasDeActuacion[], fechaProxima)
Clase: fecha (ciudad, dia)

     De todo recital se conoce el nombre de la banda y la lista de temas que tocarán durante
    el recital.
     Un evento ocasional es un recital que además tiene el motivo (a beneficio, show de TV
    o show privado), el nombre del contratante del recital y el día del evento.
     Una gira es un recital que además tiene un nombre y las “fechas” donde se repetirá la
    actuación. De cada “fecha” se conoce la ciudad y el día. Además la gira guarda el
    número de la fecha en la que se tocará próximamente (actual).

a) Genere las clases necesarias. Implemente métodos getters/setters adecuados.

b) Implemente los constructores. El constructor de recitales recibe el nombre de la banda
y la cantidad de temas que tendrá el recital. El constructor de eventos ocasionales además
recibe el motivo, el nombre del contratante y día del evento. El constructor de giras
además recibe el nombre de la gira y la cantidad de fechas que tendrá.

i. Cualquier recital debe saber responder a los mensajes:
     agregarTema que recibe el nombre de un tema y lo agrega a la lista de temas.
     actuar que imprime (por consola) para cada tema la leyenda “y ahora
    tocaremos…” seguido por el nombre del tema.
 */
package Examen;

/**
 *
 * @author Fran
 */
public abstract class Recital {
    private String nombreBanda;
    private String [] listaTemas;
    private int cantTemas;
    private int guardadas = 0;

    public Recital(String nombreBanda, int cantTemas) {
        this.nombreBanda = nombreBanda;
        this.cantTemas = cantTemas;
        listaTemas = new String [cantTemas];
    }
    
    private boolean estaLleno(){
        return guardadas == cantTemas;
    }
    
    public boolean agregarTema(String nombreTema){
        if(!estaLleno()){
            listaTemas[guardadas] = new String();
            listaTemas[guardadas]=nombreTema;
            guardadas++;
            return true;
        }
        else return false;
    }
    public void actuar(){
        for (int i =0;i<cantTemas;i++){
            System.out.println("Y ahora tocaremos... "+listaTemas[i]);
        }
    }

    public int getCantTemas() {
        return cantTemas;
    }
    
    
    public abstract double calcularCosto();
}
