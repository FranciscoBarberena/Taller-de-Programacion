/*
/*

3- Un productor musical desea administrar los recitales que organiza, que pueden ser:
eventos ocasionales y giras.

Clase abstracta: recital (nombreBanda,listaTemas)
Subclases: EventoOcasional (motivo,nombreContratante,diaEvento) y Gira (nombreGira, fechasDeActuacion[], fechaProxima)
Clase: fecha (ciudad, dia)

     De todo recital se conoce el nombre de la banda y la lista de temas que tocarán durante
    el recital.
     Un evento ocasional es un recital que además tiene el motivo (a beneficio, show de TV
    o show privado), el nombre del contratante del recital y el día del evento.
     Una gira es un recital que además tiene un nombre y las “fechas” donde se repetirá la
    actuación. De cada “fecha” se conoce la ciudad y el día. Además la gira guarda el
    número de la fecha en la que se tocará próximamente (actual).

a) Genere las clases necesarias. Implemente métodos getters/setters adecuados.

b) Implemente los constructores. El constructor de recitales recibe el nombre de la banda
y la cantidad de temas que tendrá el recital. El constructor de eventos ocasionales además
recibe el motivo, el nombre del contratante y día del evento. El constructor de giras
además recibe el nombre de la gira y la cantidad de fechas que tendrá.

iii. El evento ocasional debe saber responder al mensaje actuar de manera distinta:
     Si es un show de beneficencia se imprime la leyenda “Recuerden colaborar con…“
    seguido del nombre del contratante.
     Si es un show de TV se imprime “Saludos amigos televidentes”
     Si es un show privado se imprime “Un feliz cumpleaños para…” seguido del
    nombre del contratante.
    Independientemente del motivo del evento, luego se imprime el listado de temas como
    lo hace cualquier recital.

  iv. Todo recital debe saber responder al mensaje calcularCosto teniendo en cuenta lo
    siguiente. Si es un evento ocasional devuelve 0 si es a beneficio, 50000 si es un show de TV
    y 150000 si es privado. Las giras deben devolver 30000 por cada fecha de la misma.
 */
package Examen;

import PaqueteLectura.GeneradorAleatorio;

/**
 *
 * @author Fran
 */
public class EventoOcasional extends Recital{
    private String motivo;
    private String nombreContratante;
    private String diaEvento;
    
    
    public EventoOcasional(String motivo, String nombreContratante, String diaEvento, String nombreBanda, int cantTemas) {
        super(nombreBanda, cantTemas);
        this.motivo = motivo;
        this.nombreContratante = nombreContratante;
        this.diaEvento = diaEvento;
        for (int i =0; i<getCantTemas();i++){
            agregarTema(GeneradorAleatorio.generarString(10));
        }
    }
    
    public void actuar(){
        if (motivo.equals("a beneficio"))
            System.out.println("Recuerden colaborar con "+getNombreContratante());
        else if (motivo.equals("show de TV"))
            System.out.println("Saludos amigos televidentes");
        else 
            System.out.println("Un feliz cumpleaños para "+ getNombreContratante());
        super.actuar();
    }

    private String getNombreContratante() {
        return nombreContratante;
    }
    
    public double calcularCosto(){
        if (motivo.equals("a beneficio"))
            return 0;
        else if (motivo.equals("show de TV"))
            return 50000;
        else 
            return 150000;
    }
    
    
}
