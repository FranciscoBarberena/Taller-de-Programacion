/*
/*

3- Un productor musical desea administrar los recitales que organiza, que pueden ser:
eventos ocasionales y giras.

Clase abstracta: recital (nombreBanda,listaTemas)
Subclases: EventoOcasional (motivo,nombreContratante,diaEvento) y Gira (nombreGira, fechasDeActuacion[], fechaProxima)
Clase: fecha (ciudad, dia)

     De todo recital se conoce el nombre de la banda y la lista de temas que tocarán durante
    el recital.
     Un evento ocasional es un recital que además tiene el motivo (a beneficio, show de TV
    o show privado), el nombre del contratante del recital y el día del evento.
     Una gira es un recital que además tiene un nombre y las “fechas” donde se repetirá la
    actuación. De cada “fecha” se conoce la ciudad y el día. Además la gira guarda el
    número de la fecha en la que se tocará próximamente (actual).

a) Genere las clases necesarias. Implemente métodos getters/setters adecuados.

b) Implemente los constructores. El constructor de recitales recibe el nombre de la banda
y la cantidad de temas que tendrá el recital. El constructor de eventos ocasionales además
recibe el motivo, el nombre del contratante y día del evento. El constructor de giras
además recibe el nombre de la gira y la cantidad de fechas que tendrá.

ii. La gira debe saber responder a los mensajes:
     agregarFecha que recibe una “fecha” y la agrega adecuadamente.
     La gira debe responder al mensaje actuar de manera distinta. Imprime la leyenda
    “Buenas noches …” seguido del nombre de la ciudad de la fecha “actual”. Luego
    debe imprimir el listado de temas como lo hace cualquier recital. Además debe
    establecer la siguiente fecha de la gira como la nueva “actual”.

  iv. Todo recital debe saber responder al mensaje calcularCosto teniendo en cuenta lo
    siguiente. Si es un evento ocasional devuelve 0 si es a beneficio, 50000 si es un show de TV
    y 150000 si es privado. Las giras deben devolver 30000 por cada fecha de la misma.
 */
package Examen;

import PaqueteLectura.GeneradorAleatorio;

/**
 *
 * @author Fran
 */
public class Gira extends Recital {
    private String nombreGira;
    private Fecha[] fechasDeActuacion;
    private Fecha actual;
    private int proxima;
    private int cantFechas;
    private int guardadas;

    public Gira(String nombreGira, int cantFechas, String nombreBanda, int cantTemas) {
  
        super(nombreBanda, cantTemas);
        GeneradorAleatorio.iniciar();
        this.nombreGira = nombreGira;
        this.cantFechas = cantFechas;
        fechasDeActuacion = new Fecha[cantFechas];
        this.proxima = 0;
        this.guardadas = 0;
        Fecha fechaAux;
        for (int i =0; i<getCantTemas();i++){ //ESTO VA EN EL CONSTRUCTOR O EN EL MAIN???
            agregarTema(GeneradorAleatorio.generarString(10));
            fechaAux = new Fecha(GeneradorAleatorio.generarString(10),((GeneradorAleatorio.generarInt(31)+1)+"/"+(GeneradorAleatorio.generarInt(12)+1)));
            agregarFecha(fechaAux);
        }
    }
    
    public boolean agregarFecha(Fecha f){
        if (!estaLleno()){
            fechasDeActuacion[guardadas]= f;
            guardadas++;
            return true;
        } else return false;
    }
    
    private boolean estaLleno(){
        return guardadas == cantFechas;
    }
    
    public void actuar(){
        setActual(fechasDeActuacion[proxima]);
        System.out.println("Buenas noches "+actual.getCiudad());
        super.actuar();
        if (proxima!=19){
            proxima++;
            setActual(fechasDeActuacion[proxima]);
        }
    }

    private void setActual(Fecha actual) {
        this.actual = actual;
    }
    
    
    
    public double calcularCosto(){
        return 30000*cantFechas;
    }
}
