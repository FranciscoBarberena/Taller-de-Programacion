package Examen;

/*
2- Queremos un sistema para gestionar estacionamientos. Un estacionamiento conoce su
nombre, dirección, hora de apertura, hora de cierre, y almacena para cada número de piso
(1..N) y número de plaza (1..M), el auto que ocupa dicho lugar. De los autos se conoce
nombre del dueño y patente.

matriz NxM

Clases: estacionamiento (nombre,direccion,hora de apertura, hora de cierre, matriz de autos)
                    auto (nombre del dueño y patente)

a) Genere las clases, incluyendo getters y setters adecuados.
b) Implemente constructores. En particular, para el estacionamiento:

    - Un constructor debe recibir nombre y dirección, e iniciar el estacionamiento
    con hora de apertura “8:00”, hora de cierre “21:00”, y para 5 pisos y 10 plazas
    por piso. El estacionamiento inicialmente no tiene autos.
    - Otro constructor debe recibir nombre, dirección, hora de apertura, hora de
    cierre, el número de pisos (N) y el número de plazas por piso (M) e iniciar el
    estacionamiento con los datos recibidos y sin autos.

c) Implemente métodos para:
    - Dado un auto A, un número de piso X y un número de plaza Y, registrar al auto
    en el estacionamiento en el lugar X,Y. Suponga que X, Y son válidos (es decir,
    están en rango 1..N y 1..M respectivamente) y que el lugar está desocupado.
    - Dada una patente, obtener un String que contenga el número de piso y plaza
    donde está dicho auto en el estacionamiento. En caso de no encontrarse,
    retornar el mensaje “Auto Inexistente”.
    - Obtener un String con la representación del estacionamiento. Ejemplo: “Piso 1
    Plaza 1: libre Piso 1 Plaza 2: representación del auto …
    Piso 2 Plaza 1: libre … etc”
    - Dado un número de plaza Y, obtener la cantidad de autos ubicados en dicha
    plaza (teniendo en cuenta todos los pisos).

d) Realice un programa que instancie un estacionamiento con 3 pisos y 3 plazas por piso.
Registre 6 autos en el estacionamiento en distintos lugares.
Muestre la representación String del estacionamiento en consola.
Muestre la cantidad de autos ubicados en la plaza 1.
Lea una patente por teclado e informe si dicho auto se encuentra en el
estacionamiento o no. En caso de encontrarse, la información a imprimir es el piso y
plaza que ocupa
 */

/**
 *
 * @author Fran
 */
import PaqueteLectura.Lector;
import PaqueteLectura.GeneradorAleatorio;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GeneradorAleatorio.iniciar();
        String patenteAux;
        String nombreAux;
        Estacionamiento est = new Estacionamiento("Mega estacionamiento","120 y 50","7:00","22:00",3,3);
        for (int i=0;i<6;i++){

            nombreAux= GeneradorAleatorio.generarString(12);

            patenteAux = GeneradorAleatorio.generarString(6);
            Auto autoAux = new Auto(nombreAux,patenteAux);
            est.agregarAuto(autoAux, GeneradorAleatorio.generarInt(3), GeneradorAleatorio.generarInt(3)); /*genera piso y plaza automaticamente, por lo que 
                                                                                                        podrian repetirse. Pero el enunciado dice que asuma que
                                                                                                        la posicion generada está desocupada*/
        }
        System.out.println(est.toString());
        System.out.println("La cantidad de autos en la plaza 1 es: "+est.cantidadEnPlaza(1));
        System.out.print("Ingresa la patente a buscar: ");
        patenteAux = Lector.leerString();
        System.out.println(est.findCar(patenteAux));
    }
    
}
